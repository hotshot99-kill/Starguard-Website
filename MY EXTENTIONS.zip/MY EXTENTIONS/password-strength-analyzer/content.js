// Content script for password strength checking on web pages
class WebPasswordChecker {
    constructor() {
        this.settings = {
            minLength: 8,
            requireUppercase: true,
            requireLowercase: true,
            requireNumbers: true,
            requireSymbols: true
        };
        
        this.commonPasswords = [
            'password', '123456', '123456789', 'qwerty', 'abc123', 'password123',
            'admin', 'letmein', 'welcome', 'monkey', '1234567890', 'password1',
            'qwerty123', 'dragon', 'master', 'login', 'admin123', 'root',
            'pass', '12345', 'iloveyou', 'princess', 'rockyou', '1234567',
            'trustno1', '000000', 'jesus', 'sunshine', '123123', 'football'
        ];
        
        this.init();
    }

    init() {
        this.loadSettings();
        this.observePasswordFields();
        this.attachToExistingFields();
    }

    loadSettings() {
        chrome.storage.sync.get(['passwordSettings'], (result) => {
            if (result.passwordSettings) {
                this.settings = { ...this.settings, ...result.passwordSettings };
            }
        });
    }

    observePasswordFields() {
        // Observer for dynamically added password fields
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                mutation.addedNodes.forEach((node) => {
                    if (node.nodeType === 1) { // Element node
                        const passwordFields = node.querySelectorAll('input[type="password"]');
                        passwordFields.forEach(field => this.attachStrengthChecker(field));
                    }
                });
            });
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
    }

    attachToExistingFields() {
        // Attach to existing password fields
        const passwordFields = document.querySelectorAll('input[type="password"]');
        passwordFields.forEach(field => this.attachStrengthChecker(field));
    }

    attachStrengthChecker(passwordField) {
        // Skip if already attached
        if (passwordField.dataset.strengthCheckerAttached) return;
        
        passwordField.dataset.strengthCheckerAttached = 'true';
        
        // Create strength indicator
        const strengthIndicator = this.createStrengthIndicator();
        
        // Insert after password field
        passwordField.parentNode.insertBefore(strengthIndicator, passwordField.nextSibling);
        
        // Add event listener
        passwordField.addEventListener('input', (e) => {
            this.checkPasswordStrength(e.target.value, strengthIndicator);
        });

        // Add focus/blur events for better UX
        passwordField.addEventListener('focus', () => {
            strengthIndicator.style.display = 'block';
        });
    }

    createStrengthIndicator() {
        const container = document.createElement('div');
        container.className = 'password-strength-checker';
        container.innerHTML = `
            <div class="strength-bar-container">
                <div class="strength-bar">
                    <div class="strength-fill"></div>
                </div>
                <div class="strength-text">Start typing...</div>
            </div>
            <div class="strength-suggestions" style="display: none;"></div>
        `;
        return container;
    }

    checkPasswordStrength(password, indicator) {
        const strengthFill = indicator.querySelector('.strength-fill');
        const strengthText = indicator.querySelector('.strength-text');
        const suggestionsContainer = indicator.querySelector('.strength-suggestions');

        if (!password) {
            strengthFill.className = 'strength-fill';
            strengthFill.style.width = '0%';
            strengthText.textContent = 'Start typing...';
            strengthText.className = 'strength-text';
            suggestionsContainer.style.display = 'none';
            return;
        }

        // Calculate strength
        let score = 0;
        const checks = {
            length: password.length >= this.settings.minLength,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            numbers: /\d/.test(password),
            symbols: /[!@#$%^&*(),.?\":{}|<>]/.test(password),
            unique: !this.commonPasswords.includes(password.toLowerCase())
        };

        // Calculate score
        score += checks.length ? 2 : 0;
        score += checks.uppercase ? 1 : 0;
        score += checks.lowercase ? 1 : 0;
        score += checks.numbers ? 1 : 0;
        score += checks.symbols ? 2 : 0;
        score += checks.unique ? 1 : 0;

        // Bonus points
        if (password.length >= 12) score += 1;
        if (password.length >= 16) score += 1;
        if (/[!@#$%^&*(),.?\":{}|<>].*[!@#$%^&*(),.?\":{}|<>]/.test(password)) score += 1;

        // Penalties
        if (/123|abc|qwe|asd|zxc/i.test(password)) score -= 1;
        if (/(.)\1{2,}/.test(password)) score -= 1;

        // Determine strength
        let strength, strengthTextContent, emoji;
        if (score <= 2) {
            strength = 'weak';
            strengthTextContent = 'Weak';
            emoji = '🔴';
        } else if (score <= 5) {
            strength = 'fair';
            strengthTextContent = 'Fair';
            emoji = '🟡';
        } else if (score <= 7) {
            strength = 'good';
            strengthTextContent = 'Good';
            emoji = '🔵';
        } else {
            strength = 'strong';
            strengthTextContent = 'Strong';
            emoji = '🟢';
        }

        // Update UI
        strengthFill.className = `strength-fill ${strength}`;
        strengthText.className = `strength-text ${strength}`;
        strengthText.innerHTML = `${emoji} ${strengthTextContent}`;

        // Show suggestions for weak/fair passwords
        if (strength === 'weak' || strength === 'fair') {
            this.showSuggestions(checks, suggestionsContainer, password);
        } else {
            suggestionsContainer.style.display = 'none';
        }

        // Check for breaches (async)
        this.checkBreachDatabase(password, indicator);
    }

    showSuggestions(checks, container, password) {
        const suggestions = [];

        if (!checks.length) {
            suggestions.push(`Make it at least ${this.settings.minLength} characters`);
        }
        if (!checks.uppercase && this.settings.requireUppercase) {
            suggestions.push('Add uppercase letters');
        }
        if (!checks.lowercase && this.settings.requireLowercase) {
            suggestions.push('Add lowercase letters');
        }
        if (!checks.numbers && this.settings.requireNumbers) {
            suggestions.push('Include numbers');
        }
        if (!checks.symbols && this.settings.requireSymbols) {
            suggestions.push('Add special symbols');
        }
        if (!checks.unique) {
            suggestions.push('Avoid common passwords');
        }

        if (suggestions.length > 0) {
            container.innerHTML = `
                <div class="suggestion-title">💡 Try:</div>
                ${suggestions.map(s => `<div class="suggestion-item">${s}</div>`).join('')}
            `;
            container.style.display = 'block';
        }
    }

    async checkBreachDatabase(password, indicator) {
        try {
            // Create SHA-1 hash
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-1', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
            
            const prefix = hashHex.substring(0, 5);
            const suffix = hashHex.substring(5);

            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            const dataText = await response.text();
            
            const found = dataText.split('\n').some(line => {
                const [hash] = line.split(':');
                return hash === suffix;
            });

            if (found) {
                this.showBreachWarning(indicator);
            }
        } catch (error) {
            console.warn('Could not check breach database:', error);
        }
    }

    showBreachWarning(indicator) {
        const suggestionsContainer = indicator.querySelector('.strength-suggestions');
        
        if (!suggestionsContainer.innerHTML.includes('breach-warning')) {
            const warningDiv = document.createElement('div');
            warningDiv.className = 'breach-warning';
            warningDiv.innerHTML = '🔓 This password was found in data breaches. Please use a different one.';
            suggestionsContainer.appendChild(warningDiv);
            suggestionsContainer.style.display = 'block';
        }
    }
}

// Initialize when DOM is loaded
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
        new WebPasswordChecker();
    });
} else {
    new WebPasswordChecker();
}