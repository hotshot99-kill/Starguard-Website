class PasswordStrengthChecker {
    constructor() {
        this.commonPasswords = [
            'password', '123456', '123456789', 'qwerty', 'abc123', 'password123',
            'admin', 'letmein', 'welcome', 'monkey', '1234567890', 'password1',
            'qwerty123', 'dragon', 'master', 'login', 'admin123', 'root',
            'pass', '12345', 'iloveyou', 'princess', 'rockyou', '1234567',
            'trustno1', '000000', 'jesus', 'sunshine', '123123', 'football'
        ];
        
        this.settings = {
            minLength: 8,
            requireUppercase: true,
            requireLowercase: true,
            requireNumbers: true,
            requireSymbols: true
        };
        
        this.init();
        this.loadSettings();
    }

    init() {
        this.bindEvents();
        this.loadZxcvbn();
    }

    async loadZxcvbn() {
        // For demo purposes, we'll implement a basic strength checker
        // In a real extension, you'd load the zxcvbn library
        console.log('Password strength checker initialized');
    }

    bindEvents() {
        const passwordInput = document.getElementById('passwordInput');
        const togglePassword = document.getElementById('togglePassword');
        const generatePassword = document.getElementById('generatePassword');
        const settingsToggle = document.getElementById('settingsToggle');
        const saveSettings = document.getElementById('saveSettings');
        const copyGenerated = document.getElementById('copyGenerated');

        passwordInput.addEventListener('input', (e) => {
            this.checkPasswordStrength(e.target.value);
        });

        togglePassword.addEventListener('click', () => {
            this.togglePasswordVisibility();
        });

        generatePassword.addEventListener('click', () => {
            this.generateStrongPassword();
        });

        settingsToggle.addEventListener('click', () => {
            this.toggleSettings();
        });

        saveSettings.addEventListener('click', () => {
            this.saveSettings();
        });

        copyGenerated.addEventListener('click', () => {
            this.copyToClipboard();
        });
    }

    checkPasswordStrength(password) {
        if (!password) {
            this.resetStrengthIndicator();
            return;
        }

        // Show password health panel
        document.getElementById('passwordHealth').style.display = 'block';

        // Basic strength calculation
        let score = 0;
        const checks = {
            length: password.length >= this.settings.minLength,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            numbers: /\d/.test(password),
            symbols: /[!@#$%^&*(),.?\":{}|<>]/.test(password),
            unique: !this.commonPasswords.includes(password.toLowerCase()),
            notBreach: true // Will be updated by breach check
        };

        // Update health checks UI
        this.updateHealthCheck('lengthCheck', checks.length);
        this.updateHealthCheck('uppercaseCheck', checks.uppercase);
        this.updateHealthCheck('lowercaseCheck', checks.lowercase);
        this.updateHealthCheck('numberCheck', checks.numbers);
        this.updateHealthCheck('symbolCheck', checks.symbols);
        this.updateHealthCheck('uniqueCheck', checks.unique);

        // Calculate score
        score += checks.length ? 2 : 0;
        score += checks.uppercase ? 1 : 0;
        score += checks.lowercase ? 1 : 0;
        score += checks.numbers ? 1 : 0;
        score += checks.symbols ? 2 : 0;
        score += checks.unique ? 1 : 0;

        // Additional complexity bonuses
        if (password.length >= 12) score += 1;
        if (password.length >= 16) score += 1;
        if (/[!@#$%^&*(),.?\":{}|<>].*[!@#$%^&*(),.?\":{}|<>]/.test(password)) score += 1;

        // Check for common patterns (reduce score)
        if (/123|abc|qwe|asd|zxc/i.test(password)) score -= 1;
        if (/(.)\1{2,}/.test(password)) score -= 1; // Repeated characters

        // Determine strength level
        let strength, strengthText;
        if (score <= 2) {
            strength = 'weak';
            strengthText = '🔴 Weak';
        } else if (score <= 5) {
            strength = 'fair';
            strengthText = '🟡 Fair';
        } else if (score <= 7) {
            strength = 'good';
            strengthText = '🔵 Good';
        } else {
            strength = 'strong';
            strengthText = '🟢 Strong';
        }

        // Update UI
        this.updateStrengthIndicator(strength, strengthText);
        this.showSuggestions(password, checks, strength);
        
        // Check breach database
        this.checkBreachDatabase(password);
    }

    updateHealthCheck(elementId, passed) {
        const element = document.getElementById(elementId);
        const statusElement = element.querySelector('.status');
        statusElement.textContent = passed ? '✅' : '❌';
    }

    updateStrengthIndicator(strength, text) {
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        
        strengthFill.className = `strength-fill ${strength}`;
        strengthText.className = `strength-text ${strength}`;
        strengthText.textContent = text;
    }

    resetStrengthIndicator() {
        const strengthFill = document.getElementById('strengthFill');
        const strengthText = document.getElementById('strengthText');
        
        strengthFill.className = 'strength-fill';
        strengthFill.style.width = '0%';
        strengthText.className = 'strength-text';
        strengthText.textContent = 'Start typing...';
        
        document.getElementById('passwordHealth').style.display = 'none';
        document.getElementById('suggestions').style.display = 'none';
    }

    showSuggestions(password, checks, strength) {
        const suggestionsContainer = document.getElementById('suggestions');
        const suggestions = [];

        if (!checks.length) {
            suggestions.push(`Make it at least ${this.settings.minLength} characters long`);
        }
        if (!checks.uppercase && this.settings.requireUppercase) {
            suggestions.push('Add uppercase letters (A-Z)');
        }
        if (!checks.lowercase && this.settings.requireLowercase) {
            suggestions.push('Add lowercase letters (a-z)');
        }
        if (!checks.numbers && this.settings.requireNumbers) {
            suggestions.push('Include numbers (0-9)');
        }
        if (!checks.symbols && this.settings.requireSymbols) {
            suggestions.push('Add special symbols (!@#$%^&*)');
        }
        if (!checks.unique) {
            suggestions.push('Avoid common passwords');
        }
        if (password.length < 12) {
            suggestions.push('Consider making it longer for better security');
        }

        if (suggestions.length > 0) {
            suggestionsContainer.style.display = 'block';
            suggestionsContainer.innerHTML = `
                <h4>💡 Suggestions to improve:</h4>
                ${suggestions.map(s => `<div class="suggestion-item">${s}</div>`).join('')}
            `;
        } else if (strength === 'strong') {
            suggestionsContainer.style.display = 'block';
            suggestionsContainer.innerHTML = `
                <div class="suggestion-item" style="border-left-color: #2ed573; background: #f0fff4;">
                    ✅ Excellent! Your password is strong and secure.
                </div>
            `;
        } else {
            suggestionsContainer.style.display = 'none';
        }
    }

    async checkBreachDatabase(password) {
        const breachElement = document.getElementById('breachCheck');
        const statusElement = breachElement.querySelector('.status');
        const textElement = breachElement.querySelector('.text');
        
        statusElement.textContent = '⏳';
        textElement.textContent = 'Checking breach databases...';

        try {
            // Create SHA-1 hash of password (first 5 characters)
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-1', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
            
            const prefix = hashHex.substring(0, 5);
            const suffix = hashHex.substring(5);

            // Check Have I Been Pwned API
            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            const data_text = await response.text();
            
            const found = data_text.split('\n').some(line => {
                const [hash] = line.split(':');
                return hash === suffix;
            });

            if (found) {
                statusElement.textContent = '🔓';
                textElement.textContent = 'Found in breach databases!';
                this.showBreachWarning();
            } else {
                statusElement.textContent = '✅';
                textElement.textContent = 'Not found in known breaches';
            }
        } catch (error) {
            statusElement.textContent = '⚠️';
            textElement.textContent = 'Could not check breach database';
        }
    }

    showBreachWarning() {
        const suggestionsContainer = document.getElementById('suggestions');
        const warningHtml = `
            <div class="breach-warning">
                🔓 <strong>Security Alert:</strong> This password has been exposed in data breaches. 
                Please choose a different password for your security.
            </div>
        `;
        
        if (suggestionsContainer.innerHTML.includes('breach-warning')) return;
        
        suggestionsContainer.style.display = 'block';
        suggestionsContainer.innerHTML += warningHtml;
    }

    generateStrongPassword() {
        const length = Math.max(16, this.settings.minLength);
        const lowercase = 'abcdefghijklmnopqrstuvwxyz';
        const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
        
        let charset = '';
        let password = '';
        
        // Ensure required character types
        if (this.settings.requireLowercase) {
            charset += lowercase;
            password += lowercase[Math.floor(Math.random() * lowercase.length)];
        }
        if (this.settings.requireUppercase) {
            charset += uppercase;
            password += uppercase[Math.floor(Math.random() * uppercase.length)];
        }
        if (this.settings.requireNumbers) {
            charset += numbers;
            password += numbers[Math.floor(Math.random() * numbers.length)];
        }
        if (this.settings.requireSymbols) {
            charset += symbols;
            password += symbols[Math.floor(Math.random() * symbols.length)];
        }
        
        // Fill remaining length
        for (let i = password.length; i < length; i++) {
            password += charset[Math.floor(Math.random() * charset.length)];
        }
        
        // Shuffle password
        password = password.split('').sort(() => Math.random() - 0.5).join('');
        
        // Display generated password
        const generatedContainer = document.getElementById('generatedPassword');
        const generatedText = document.getElementById('generatedText');
        
        generatedText.value = password;
        generatedContainer.style.display = 'flex';
        
        // Auto-check the generated password
        document.getElementById('passwordInput').value = password;
        this.checkPasswordStrength(password);
    }

    togglePasswordVisibility() {
        const passwordInput = document.getElementById('passwordInput');
        const toggleBtn = document.getElementById('togglePassword');
        
        if (passwordInput.type === 'password') {
            passwordInput.type = 'text';
            toggleBtn.textContent = '🙈';
        } else {
            passwordInput.type = 'password';
            toggleBtn.textContent = '👁️';
        }
    }

    toggleSettings() {
        const settingsPanel = document.getElementById('settingsPanel');
        settingsPanel.style.display = settingsPanel.style.display === 'none' ? 'block' : 'none';
    }

    loadSettings() {
        chrome.storage.sync.get(['passwordSettings'], (result) => {
            if (result.passwordSettings) {
                this.settings = { ...this.settings, ...result.passwordSettings };
                this.updateSettingsUI();
            }
        });
    }

    updateSettingsUI() {
        document.getElementById('minLength').value = this.settings.minLength;
        document.getElementById('requireUppercase').checked = this.settings.requireUppercase;
        document.getElementById('requireLowercase').checked = this.settings.requireLowercase;
        document.getElementById('requireNumbers').checked = this.settings.requireNumbers;
        document.getElementById('requireSymbols').checked = this.settings.requireSymbols;
    }

    saveSettings() {
        this.settings = {
            minLength: parseInt(document.getElementById('minLength').value),
            requireUppercase: document.getElementById('requireUppercase').checked,
            requireLowercase: document.getElementById('requireLowercase').checked,
            requireNumbers: document.getElementById('requireNumbers').checked,
            requireSymbols: document.getElementById('requireSymbols').checked
        };

        chrome.storage.sync.set({ passwordSettings: this.settings }, () => {
            // Show success message
            const saveBtn = document.getElementById('saveSettings');
            const originalText = saveBtn.textContent;
            saveBtn.textContent = '✅ Saved!';
            saveBtn.style.background = '#2ed573';
            
            setTimeout(() => {
                saveBtn.textContent = originalText;
                saveBtn.style.background = '';
            }, 2000);
        });
    }

    async copyToClipboard() {
        const generatedText = document.getElementById('generatedText');
        const copyBtn = document.getElementById('copyGenerated');
        
        try {
            await navigator.clipboard.writeText(generatedText.value);
            
            // Show success feedback
            const originalText = copyBtn.textContent;
            copyBtn.textContent = '✅';
            copyBtn.style.background = '#2ed573';
            
            setTimeout(() => {
                copyBtn.textContent = originalText;
                copyBtn.style.background = '';
            }, 2000);
        } catch (err) {
            console.error('Failed to copy: ', err);
        }
    }
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new PasswordStrengthChecker();
});