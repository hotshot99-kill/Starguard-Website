// Background script for password strength checker extension
class BackgroundPasswordChecker {
    constructor() {
        this.init();
    }

    init() {
        this.setupContextMenus();
        this.handleInstallation();
        this.handleMessages();
    }

    setupContextMenus() {
        chrome.runtime.onInstalled.addListener(() => {
            chrome.contextMenus.create({
                id: 'checkPasswordStrength',
                title: 'Check Password Strength',
                contexts: ['selection']
            });

            chrome.contextMenus.create({
                id: 'generatePassword',
                title: 'Generate Strong Password',
                contexts: ['editable']
            });
        });

        chrome.contextMenus.onClicked.addListener((info, tab) => {
            if (info.menuItemId === 'checkPasswordStrength') {
                this.checkSelectedText(info.selectionText, tab);
            } else if (info.menuItemId === 'generatePassword') {
                this.generatePasswordForField(tab);
            }
        });
    }

    handleInstallation() {
        chrome.runtime.onInstalled.addListener((details) => {
            if (details.reason === 'install') {
                // Set default settings
                const defaultSettings = {
                    minLength: 8,
                    requireUppercase: true,
                    requireLowercase: true,
                    requireNumbers: true,
                    requireSymbols: true
                };

                chrome.storage.sync.set({ passwordSettings: defaultSettings });

                // Open welcome page
                chrome.tabs.create({
                    url: chrome.runtime.getURL('welcome.html')
                });
            }
        });
    }

    handleMessages() {
        chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
            if (request.action === 'checkPassword') {
                this.performPasswordCheck(request.password).then(sendResponse);
                return true; // Indicates async response
            } else if (request.action === 'generatePassword') {
                const password = this.generateStrongPassword(request.settings);
                sendResponse({ password });
            }
        });
    }

    async checkSelectedText(text, tab) {
        if (!text) return;

        const result = await this.performPasswordCheck(text);
        
        // Send result to content script
        chrome.tabs.sendMessage(tab.id, {
            action: 'showPasswordStrength',
            password: text,
            result: result
        });
    }

    async generatePasswordForField(tab) {
        // Get settings
        const settings = await this.getSettings();
        const password = this.generateStrongPassword(settings);

        // Send to content script
        chrome.tabs.sendMessage(tab.id, {
            action: 'insertGeneratedPassword',
            password: password
        });
    }

    async performPasswordCheck(password) {
        const settings = await this.getSettings();
        
        // Basic strength calculation
        let score = 0;
        const checks = {
            length: password.length >= settings.minLength,
            uppercase: /[A-Z]/.test(password),
            lowercase: /[a-z]/.test(password),
            numbers: /\d/.test(password),
            symbols: /[!@#$%^&*(),.?\":{}|<>]/.test(password),
            unique: !this.isCommonPassword(password)
        };

        // Calculate score
        score += checks.length ? 2 : 0;
        score += checks.uppercase ? 1 : 0;
        score += checks.lowercase ? 1 : 0;
        score += checks.numbers ? 1 : 0;
        score += checks.symbols ? 2 : 0;
        score += checks.unique ? 1 : 0;

        // Bonus points
        if (password.length >= 12) score += 1;
        if (password.length >= 16) score += 1;

        // Determine strength
        let strength;
        if (score <= 2) strength = 'weak';
        else if (score <= 5) strength = 'fair';
        else if (score <= 7) strength = 'good';
        else strength = 'strong';

        // Check breach database
        const breachStatus = await this.checkBreachDatabase(password);

        return {
            strength,
            score,
            checks,
            breachStatus,
            suggestions: this.generateSuggestions(checks, settings)
        };
    }

    async getSettings() {
        return new Promise((resolve) => {
            chrome.storage.sync.get(['passwordSettings'], (result) => {
                const defaultSettings = {
                    minLength: 8,
                    requireUppercase: true,
                    requireLowercase: true,
                    requireNumbers: true,
                    requireSymbols: true
                };
                resolve(result.passwordSettings || defaultSettings);
            });
        });
    }

    isCommonPassword(password) {
        const commonPasswords = [
            'password', '123456', '123456789', 'qwerty', 'abc123', 'password123',
            'admin', 'letmein', 'welcome', 'monkey', '1234567890', 'password1',
            'qwerty123', 'dragon', 'master', 'login', 'admin123', 'root'
        ];
        return commonPasswords.includes(password.toLowerCase());
    }

    async checkBreachDatabase(password) {
        try {
            // Create SHA-1 hash
            const encoder = new TextEncoder();
            const data = encoder.encode(password);
            const hashBuffer = await crypto.subtle.digest('SHA-1', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            const hashHex = hashArray.map(b => b.toString(16).padStart(2, '0')).join('').toUpperCase();
            
            const prefix = hashHex.substring(0, 5);
            const suffix = hashHex.substring(5);

            const response = await fetch(`https://api.pwnedpasswords.com/range/${prefix}`);
            const dataText = await response.text();
            
            const found = dataText.split('\n').some(line => {
                const [hash, count] = line.split(':');
                if (hash === suffix) {
                    return { found: true, count: parseInt(count) };
                }
                return false;
            });

            return { found: !!found, safe: !found };
        } catch (error) {
            return { found: false, safe: true, error: 'Could not check' };
        }
    }

    generateSuggestions(checks, settings) {
        const suggestions = [];

        if (!checks.length) {
            suggestions.push(`Make it at least ${settings.minLength} characters long`);
        }
        if (!checks.uppercase && settings.requireUppercase) {
            suggestions.push('Add uppercase letters (A-Z)');
        }
        if (!checks.lowercase && settings.requireLowercase) {
            suggestions.push('Add lowercase letters (a-z)');
        }
        if (!checks.numbers && settings.requireNumbers) {
            suggestions.push('Include numbers (0-9)');
        }
        if (!checks.symbols && settings.requireSymbols) {
            suggestions.push('Add special symbols (!@#$%^&*)');
        }
        if (!checks.unique) {
            suggestions.push('Avoid common passwords');
        }

        return suggestions;
    }

    generateStrongPassword(settings) {
        const length = Math.max(16, settings.minLength);
        const lowercase = 'abcdefghijklmnopqrstuvwxyz';
        const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const numbers = '0123456789';
        const symbols = '!@#$%^&*()_+-=[]{}|;:,.<>?';
        
        let charset = '';
        let password = '';
        
        // Ensure required character types
        if (settings.requireLowercase) {
            charset += lowercase;
            password += this.getRandomChar(lowercase);
        }
        if (settings.requireUppercase) {
            charset += uppercase;
            password += this.getRandomChar(uppercase);
        }
        if (settings.requireNumbers) {
            charset += numbers;
            password += this.getRandomChar(numbers);
        }
        if (settings.requireSymbols) {
            charset += symbols;
            password += this.getRandomChar(symbols);
        }
        
        // Fill remaining length
        for (let i = password.length; i < length; i++) {
            password += this.getRandomChar(charset);
        }
        
        // Shuffle password
        return password.split('').sort(() => Math.random() - 0.5).join('');
    }

    getRandomChar(charset) {
        const crypto = window.crypto || window.msCrypto;
        const array = new Uint8Array(1);
        crypto.getRandomValues(array);
        return charset[array[0] % charset.length];
    }
}

// Initialize background script
new BackgroundPasswordChecker();