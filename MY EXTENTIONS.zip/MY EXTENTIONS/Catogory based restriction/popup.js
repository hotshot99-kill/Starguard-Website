// SafeGuard Extension Popup JavaScript
document.addEventListener('DOMContentLoaded', () => {
    
    // Extension Manager Class
    class SafeGuardManager {
        constructor() {
            this.state = {
                categories: [],
                profiles: [],
                settings: {},
                schedules: [],
                stats: {}
            };
            
            this.init();
        }

        async init() {
            await this.loadData();
            this.setupEventListeners();
            this.updateUI();
        }

        // Data Management
        async loadData() {
            try {
                const data = await chrome.storage.local.get(['categories', 'profiles', 'settings', 'schedules', 'stats']);
                
                this.state = {
                    categories: data.categories || [],
                    profiles: data.profiles || [],
                    settings: data.settings || { overridePin: '1234', customDomains: [] },
                    schedules: data.schedules || [],
                    stats: data.stats || { totalBlocked: 0, totalAttempts: 0, activeDays: 1, categoryStats: {} }
                };
                
                console.log('Data loaded:', this.state);
            } catch (error) {
                console.error('Error loading data:', error);
                this.showNotification('Error loading data', 'error');
            }
        }

        async saveData() {
            try {
                await chrome.storage.local.set(this.state);
                
                // Notify background script to update blocking rules
                const response = await chrome.runtime.sendMessage({ action: 'updateRules' });
                
                if (response && response.success) {
                    this.showNotification('Settings saved successfully!');
                } else {
                    this.showNotification('Settings saved, but rules update failed', 'error');
                }
                
                this.updateUI();
            } catch (error) {
                console.error('Error saving data:', error);
                this.showNotification('Error saving settings', 'error');
            }
        }

        // UI Management
        updateUI() {
            this.renderCategories();
            this.renderProfiles();
            this.renderSchedules();
            this.updateStatusBar();
            this.updateReports();
            this.loadSettings();
        }

        renderCategories() {
            const grid = document.getElementById('categoryGrid');
            grid.innerHTML = '';

            if (this.state.categories.length === 0) {
                grid.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">🛡️</div>
                        <div>No categories available</div>
                    </div>
                `;
                return;
            }

            this.state.categories.forEach(category => {
                const card = document.createElement('div');
                card.className = `category-card ${category.blocked ? 'blocked' : ''}`;
                card.innerHTML = `
                    <div class="category-header">
                        <div style="display: flex; align-items: center;">
                            <div class="category-icon">${category.icon || '🛡️'}</div>
                            <div class="category-info">
                                <div class="category-name">${category.name}</div>
                                <div class="category-description">${category.description}</div>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" data-id="${category.id}" ${category.blocked ? 'checked' : ''}>
                            <span class="slider"></span>
                        </label>
                    </div>
                `;
                
                const toggle = card.querySelector('input[type="checkbox"]');
                toggle.addEventListener('change', (e) => {
                    this.toggleCategory(category.id, e.target.checked);
                });
                
                grid.appendChild(card);
            });
        }

        renderProfiles() {
            const list = document.getElementById('profilesList');
            const select = document.getElementById('scheduleProfile');
            
            list.innerHTML = '';
            select.innerHTML = '';

            if (this.state.profiles.length === 0) {
                list.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">🎭</div>
                        <div>No profiles available</div>
                    </div>
                `;
                return;
            }

            this.state.profiles.forEach(profile => {
                // Profile card
                const card = document.createElement('div');
                card.className = `profile-card ${profile.active ? 'active' : ''}`;
                card.innerHTML = `
                    <div class="profile-name">${profile.name}</div>
                    <div class="profile-description">${profile.description}</div>
                `;
                card.addEventListener('click', () => {
                    this.activateProfile(profile.id);
                });
                list.appendChild(card);

                // Schedule dropdown option
                const option = document.createElement('option');
                option.value = profile.id;
                option.textContent = profile.name;
                select.appendChild(option);
            });
        }

        renderSchedules() {
            const list = document.getElementById('schedulesList');
            list.innerHTML = '';

            if (this.state.schedules.length === 0) {
                list.innerHTML = `
                    <div class="empty-state">
                        <div class="empty-state-icon">⏰</div>
                        <div>No scheduled restrictions</div>
                    </div>
                `;
                return;
            }

            this.state.schedules.forEach((schedule, index) => {
                const profile = this.state.profiles.find(p => p.id === schedule.profileId);
                const daysText = schedule.days.map(d => ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][d]).join(', ');
                
                const item = document.createElement('div');
                item.className = 'schedule-item';
                item.innerHTML = `
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <div style="font-weight: 500; margin-bottom: 4px;">${profile?.name || 'Unknown Profile'}</div>
                            <div style="font-size: 0.8rem; color: #64748b;">
                                ${schedule.startTime} - ${schedule.endTime} • ${daysText}
                            </div>
                        </div>
                        <button class="btn btn-danger" style="padding: 6px 12px; font-size: 0.75rem;" data-index="${index}">
                            Remove
                        </button>
                    </div>
                `;
                
                const removeBtn = item.querySelector('button');
                removeBtn.addEventListener('click', () => {
                    this.removeSchedule(index);
                });
                
                list.appendChild(item);
            });
        }

        updateStatusBar() {
            const activeProfile = this.state.profiles.find(p => p.active);
            const blockedCount = this.state.categories.filter(c => c.blocked).length;
            
            document.getElementById('currentProfile').textContent = activeProfile?.name || 'None';
            document.getElementById('blockedCount').textContent = blockedCount;
            
            const protectionStatus = blockedCount > 0 ? 'Active' : 'Inactive';
            document.getElementById('protectionStatus').textContent = protectionStatus;
            document.getElementById('protectionStatus').style.color = blockedCount > 0 ? '#10b981' : '#ef4444';
        }

        updateReports() {
            const stats = this.state.stats;
            
            document.getElementById('totalBlocked').textContent = stats.totalBlocked || 0;
            document.getElementById('totalAttempts').textContent = stats.totalAttempts || 0;
            document.getElementById('activeDays').textContent = stats.activeDays || 1;
            
            // Find top category
            const categoryStats = stats.categoryStats || {};
            const topCategoryId = Object.keys(categoryStats).reduce((a, b) => 
                categoryStats[a] > categoryStats[b] ? a : b, 'N/A');
            
            if (topCategoryId !== 'N/A') {
                const topCategory = this.state.categories.find(c => c.id === topCategoryId);
                document.getElementById('topCategory').textContent = topCategory?.name || 'Unknown';
            } else {
                document.getElementById('topCategory').textContent = 'N/A';
            }
        }

        loadSettings() {
            const settings = this.state.settings;
            
            document.getElementById('overridePin').placeholder = `Current: ${'*'.repeat(4)}`;
            document.getElementById('customDomains').value = (settings.customDomains || []).join('\n');
        }

        // Event Handlers
        setupEventListeners() {
            // Tab switching
            document.querySelectorAll('.tab').forEach(tab => {
                tab.addEventListener('click', (e) => {
                    this.switchTab(e.target.dataset.tab);
                });
            });

            // Profile creation
            document.getElementById('createProfileBtn').addEventListener('click', () => {
                this.createProfile();
            });

            // Schedule management
            document.getElementById('addScheduleBtn').addEventListener('click', () => {
                this.addSchedule();
            });

            // Day selection for schedules
            document.querySelectorAll('.day-btn').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.target.classList.toggle('active');
                });
            });

            // Settings
            document.getElementById('saveSettingsBtn').addEventListener('click', () => {
                this.saveSettings();
            });

            // Reports
            document.getElementById('exportBtn').addEventListener('click', () => {
                this.exportReports();
            });

            document.getElementById('clearStatsBtn').addEventListener('click', () => {
                this.clearStats();
            });

            // Danger zone
            document.getElementById('resetBtn').addEventListener('click', () => {
                this.resetAllSettings();
            });
        }

        switchTab(tabId) {
            // Remove active class from all tabs and contents
            document.querySelectorAll('.tab').forEach(tab => tab.classList.remove('active'));
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            
            // Add active class to selected tab and content
            document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
            document.getElementById(tabId).classList.add('active');
        }

        // Category Management
        toggleCategory(categoryId, blocked) {
            const category = this.state.categories.find(c => c.id === categoryId);
            if (category) {
                category.blocked = blocked;
                this.saveData();
                // Force rule update
                chrome.runtime.sendMessage({ action: 'updateRules' });
            }
        }

        // Profile Management
        activateProfile(profileId) {
            // Deactivate all profiles
            this.state.profiles.forEach(p => p.active = false);
            
            // Activate selected profile
            const profile = this.state.profiles.find(p => p.id === profileId);
            if (profile) {
                profile.active = true;
                
                // Apply profile restrictions
                this.state.categories.forEach(cat => {
                    cat.blocked = profile.restrictions.includes(cat.id);
                });
                
                this.saveData();
                this.showNotification(`Activated ${profile.name} profile`);
            }
        }

        createProfile() {
            const name = prompt("Enter profile name:");
            if (!name) return;
            
            const description = prompt("Enter profile description (optional):") || 'Custom profile';
            
            const newProfile = {
                id: `profile_${Date.now()}`,
                name: name,
                description: description,
                active: false,
                restrictions: []
            };
            
            this.state.profiles.push(newProfile);
            this.saveData();
            this.showNotification(`Profile "${name}" created`);
        }

        // Schedule Management
        addSchedule() {
            const profileId = document.getElementById('scheduleProfile').value;
            const startTime = document.getElementById('startTime').value;
            const endTime = document.getElementById('endTime').value;
            const selectedDays = Array.from(document.querySelectorAll('.day-btn.active'))
                .map(btn => parseInt(btn.dataset.day));

            // Validation
            if (!profileId) {
                this.showNotification('Please select a profile', 'error');
                return;
            }
            
            if (!startTime || !endTime) {
                this.showNotification('Please set start and end times', 'error');
                return;
            }
            
            if (selectedDays.length === 0) {
                this.showNotification('Please select at least one day', 'error');
                return;
            }
            
            if (startTime >= endTime) {
                this.showNotification('End time must be after start time', 'error');
                return;
            }

            const schedule = {
                id: `schedule_${Date.now()}`,
                profileId,
                startTime,
                endTime,
                days: selectedDays,
                enabled: true
            };

            this.state.schedules.push(schedule);
            this.saveData();

            // Clear form
            document.getElementById('startTime').value = '';
            document.getElementById('endTime').value = '';
            document.querySelectorAll('.day-btn.active').forEach(btn => btn.classList.remove('active'));
            
            this.showNotification('Schedule added successfully!');
        }

        removeSchedule(index) {
            if (confirm('Are you sure you want to remove this schedule?')) {
                this.state.schedules.splice(index, 1);
                this.saveData();
                this.showNotification('Schedule removed');
            }
        }

        // Settings Management
        saveSettings() {
            const pin = document.getElementById('overridePin').value;
            const customDomains = document.getElementById('customDomains').value
                .split('\n')
                .map(domain => domain.trim())
                .filter(domain => domain.length > 0);

            // Validate PIN
            if (pin && (pin.length !== 4 || !/^\d+$/.test(pin))) {
                this.showNotification('PIN must be exactly 4 digits', 'error');
                return;
            }

            // Update settings
            if (pin) {
                this.state.settings.overridePin = pin;
            }
            this.state.settings.customDomains = customDomains;

            this.saveData();
            
            // Clear PIN field for security
            document.getElementById('overridePin').value = '';
        }

        // Reports Management
        exportReports() {
            const data = {
                stats: this.state.stats,
                categories: this.state.categories.map(cat => ({
                    name: cat.name,
                    blocked: cat.blocked
                })),
                exportDate: new Date().toISOString()
            };

            const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            
            const a = document.createElement('a');
            a.href = url;
            a.download = `safeguard-report-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            
            this.showNotification('Report exported successfully!');
        }

        clearStats() {
            if (confirm('Are you sure you want to clear all statistics? This cannot be undone.')) {
                this.state.stats = {
                    totalBlocked: 0,
                    totalAttempts: 0,
                    activeDays: 1,
                    categoryStats: {},
                    lastActive: new Date().toISOString().split('T')[0]
                };
                
                this.saveData();
                this.showNotification('Statistics cleared');
            }
        }

        resetAllSettings() {
            if (confirm('Are you sure you want to reset ALL settings? This will remove all profiles, schedules, and statistics. This cannot be undone.')) {
                chrome.storage.local.clear().then(() => {
                    this.showNotification('All settings reset. Please reload the extension.');
                    setTimeout(() => {
                        window.location.reload();
                    }, 2000);
                });
            }
        }

        // Utility Functions
        showNotification(message, type = 'success') {
            const notification = document.getElementById('notification');
            notification.textContent = message;
            notification.className = `notification ${type}`;
            notification.classList.add('show');

            setTimeout(() => {
                notification.classList.remove('show');
            }, 3000);
        }
    }

    // Initialize the extension manager
    const safeguard = new SafeGuardManager();
    window.safeguard = safeguard;
}); // Make it globally available for debugging