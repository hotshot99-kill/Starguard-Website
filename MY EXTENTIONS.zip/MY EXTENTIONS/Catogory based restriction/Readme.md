# SafeGuard Chrome Extension

A comprehensive website blocking extension with advanced category-based restrictions and parental controls.

## Features

### 🛡️ Category-Based Blocking
- **Adult Content**: Blocks mature and adult-oriented websites
- **Gambling**: Blocks online casinos and betting sites
- **Social Media**: Blocks social networking platforms
- **Dating Sites**: Blocks dating and relationship websites
- **Violent Content**: Blocks violent and offensive material
- **Misinformation**: Blocks known misinformation sources
- **Scams & Fraud**: Blocks fraudulent and scam websites

### 🎭 Multiple Profiles
- **Default**: Standard protection settings
- **Child Mode**: Maximum protection for children
- **Work Mode**: Focus on productivity
- **Custom Profiles**: Create your own restriction combinations

### ⏰ Scheduled Restrictions
- Time-based blocking for different categories
- Weekly schedule support
- Flexible start/end times

### 📊 Detailed Reports
- Blocking statistics and analytics
- Most blocked categories tracking
- Export functionality for reports

### ⚙️ Advanced Settings
- PIN-protected override system
- Keyword monitoring
- Custom domain blocking
- Context menu integration

## Installation

### Method 1: Load as Unpacked Extension (Development)

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" in the top right
4. Click "Load unpacked" and select the extension folder
5. The SafeGuard extension should now appear in your extensions list

### Method 2: Chrome Web Store (When Published)
*Coming soon - extension will be available on the Chrome Web Store*

## File Structure

```
safeguard-extension/
├── manifest.json          # Extension manifest
├── background.js          # Background service worker
├── content.js            # Content script for page monitoring
├── popup.html            # Extension popup interface
├── popup.js              # Popup functionality
├── blocked.html          # Blocked page template
├── rules.json            # Declarative net request rules
├── icons/                # Extension icons (16, 32, 48, 128px)
└── README.md             # This file
```

## Usage

### Basic Setup
1. Click the SafeGuard extension icon in your toolbar
2. Navigate to the "Categories" tab
3. Toggle the categories you want to block
4. Your settings are automatically saved

### Creating Profiles
1. Go to the "Profiles" tab in the extension popup
2. Click "Create New Profile"
3. Enter a name and configure restrictions
4. Switch between profiles as needed

### Scheduling Restrictions
1. Open the "Schedule" tab
2. Select a category, days, and time range
3. Click "Add Schedule" to activate

### Override System
1. When encountering a blocked site, click "Override Block"
2. Enter your 4-digit PIN (default: 1234)
3. Access is temporarily granted

### Customization
1. Go to "Settings" tab
2. Change override PIN
3. Add custom keywords for monitoring
4. Block specific domains manually

## Keyboard Shortcuts

- `Ctrl+Alt+S`: Open settings tab
- `Ctrl+Alt+B`: Block current site
- `Ctrl+Alt+C`: Check current site status
- `Escape`: Close override form

## Permissions Explained

- **activeTab**: Check current tab for blocking status
- **storage**: Save extension settings and statistics
- **tabs**: Monitor tab changes and redirects
- **declarativeNetRequest**: Block websites using Chrome's built-in blocking API
- **background**: Run background processes for continuous monitoring
- **<all_urls>**: Required to check and block any website

## Default Settings

- **Override PIN**: 1234 (change this immediately)
- **All Categories**: Disabled by default
- **Active Profile**: Default
- **Schedule**: No restrictions

## Troubleshooting

### Extension Not Working
1. Check if the extension is enabled in `chrome://extensions/`
2. Verify all permissions are granted
3. Try disabling and re-enabling the extension

### Sites Not Being Blocked
1. Ensure the category is enabled in the popup
2. Check if the site is in the category's domain list
3. Try refreshing the page after enabling blocking

### Override Not Working
1. Verify you're using the correct PIN
2. Check if the PIN was changed in settings
3. Make sure JavaScript is enabled

### Performance Issues
1. The extension uses Chrome's native blocking API for minimal performance impact
2. If experiencing slowdowns, try reducing the number of active categories

## Privacy & Security

- **No Data Collection**: SafeGuard does not collect or transmit any personal data
- **Local Storage**: All settings and statistics are stored locally on your device
- **No External Connections**: The extension operates entirely offline
- **Open Source**: All code is available for review

## Development

### Building from Source
1. Clone the repository
2. No build process required - Chrome extensions run directly from source
3. Load as unpacked extension for testing

### Contributing
1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Test thoroughly
5. Submit a pull request

### Testing
- Load the extension in Chrome developer mode
- Test blocking functionality across different categories
- Verify override system works correctly
- Check scheduled restrictions activate properly

## Version History

### v1.0.0
- Initial release
- Category-based blocking
- Multiple profiles
- Scheduled restrictions
- Override system
- Statistics and reporting

## Support

For support, feature requests, or bug reports, please create an issue in the project repository.

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Disclaimer

SafeGuard is designed to help users control their browsing habits and create safer online environments. It should not be considered a complete security solution and may not block all unwanted content. Users should combine this tool with other security measures and parental guidance as appropriate.

## Acknowledgments

- Built using Chrome Extension Manifest V3
- Uses Chrome's declarativeNetRequest API for efficient blocking
- Designed with modern web standards and accessibility in mind