// SafeGuard Content Script
(function() {
    'use strict';
    
    console.log('SafeGuard content script loaded on:', window.location.href);
    
    // Content script functionality for additional monitoring and features
    class SafeGuardContent {
        constructor() {
            this.init();
        }
        
        init() {
            this.setupKeywordMonitoring();
            this.setupPageAnalysis();
            this.addExtensionInterface();
            this.monitorDynamicContent();
        }
        
        // Monitor page for blocked keywords
        setupKeywordMonitoring() {
            // This could be expanded to monitor for specific keywords
            // and provide warnings or additional blocking
            const checkKeywords = () => {
                // Get settings from storage
                chrome.storage.local.get(['settings'], (data) => {
                    if (data.settings && data.settings.blockedKeywords) {
                        this.scanForKeywords(data.settings.blockedKeywords);
                    }
                });
            };
            
            // Check on load
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', checkKeywords);
            } else {
                checkKeywords();
            }
        }
        
        scanForKeywords(keywords) {
            if (!keywords || keywords.length === 0) return;
            
            const pageText = document.body.textContent.toLowerCase();
            const foundKeywords = keywords.filter(keyword => 
                pageText.includes(keyword.toLowerCase())
            );
            
            if (foundKeywords.length > 0) {
                this.handleKeywordDetection(foundKeywords);
            }
        }
        
        handleKeywordDetection(keywords) {
            console.log('Blocked keywords detected:', keywords);
            
            // Could show a warning overlay or redirect
            this.showKeywordWarning(keywords);
        }
        
        showKeywordWarning(keywords) {
            // Create warning overlay
            const warning = document.createElement('div');
            warning.id = 'safeguard-keyword-warning';
            warning.style.cssText = `
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                background: #fef3c7;
                border-bottom: 2px solid #f59e0b;
                padding: 12px 20px;
                z-index: 10000;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                color: #92400e;
                text-align: center;
                box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            `;
            
            warning.innerHTML = `
                <strong>⚠️ SafeGuard Warning:</strong> 
                This page contains potentially inappropriate content.
                <button id="dismiss-warning" style="
                    margin-left: 12px;
                    padding: 4px 8px;
                    background: #92400e;
                    color: white;
                    border: none;
                    border-radius: 4px;
                    cursor: pointer;
                    font-size: 12px;
                ">Dismiss</button>
            `;
            
            document.body.insertBefore(warning, document.body.firstChild);
            
            // Add dismiss functionality
            document.getElementById('dismiss-warning').addEventListener('click', () => {
                warning.remove();
            });
            
            // Auto-dismiss after 10 seconds
            setTimeout(() => {
                if (warning.parentNode) {
                    warning.remove();
                }
            }, 10000);
        }
        
        // Analyze page content for blocking decisions
        setupPageAnalysis() {
            const analyzeContent = () => {
                const currentDomain = window.location.hostname;
                const pageTitle = document.title;
                const metaDescription = this.getMetaDescription();
                
                // Send analysis data to background script
                chrome.runtime.sendMessage({
                    action: 'analyzeContent',
                    data: {
                        domain: currentDomain,
                        title: pageTitle,
                        description: metaDescription,
                        url: window.location.href
                    }
                });
            };
            
            // Analyze after page load
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', analyzeContent);
            } else {
                analyzeContent();
            }
        }
        
        getMetaDescription() {
            const metaTag = document.querySelector('meta[name="description"]');
            return metaTag ? metaTag.getAttribute('content') : '';
        }
        
        // Add SafeGuard interface elements
        addExtensionInterface() {
            // Add a small SafeGuard indicator
            const indicator = document.createElement('div');
            indicator.id = 'safeguard-indicator';
            indicator.style.cssText = `
                position: fixed;
                bottom: 20px;
                right: 20px;
                width: 40px;
                height: 40px;
                background: linear-gradient(135deg, #4f46e5, #7c3aed);
                border-radius: 50%;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-size: 16px;
                z-index: 9999;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3);
                transition: transform 0.2s ease;
                user-select: none;
            `;
            
            indicator.innerHTML = '🛡️';
            indicator.title = 'SafeGuard is protecting this page';
            
            // Add hover effect
            indicator.addEventListener('mouseenter', () => {
                indicator.style.transform = 'scale(1.1)';
            });
            
            indicator.addEventListener('mouseleave', () => {
                indicator.style.transform = 'scale(1)';
            });
            
            // Click to show extension popup
            indicator.addEventListener('click', () => {
                this.showQuickActions();
            });
            
            document.body.appendChild(indicator);
        }
        
        showQuickActions() {
            // Remove existing popup if any
            const existing = document.getElementById('safeguard-quick-actions');
            if (existing) {
                existing.remove();
                return;
            }
            
            const popup = document.createElement('div');
            popup.id = 'safeguard-quick-actions';
            popup.style.cssText = `
                position: fixed;
                bottom: 70px;
                right: 20px;
                background: white;
                border-radius: 12px;
                padding: 16px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.15);
                z-index: 10000;
                min-width: 200px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                border: 1px solid #e2e8f0;
            `;
            
            popup.innerHTML = `
                <div style="margin-bottom: 12px; font-weight: 600; color: #1e293b;">
                    SafeGuard Quick Actions
                </div>
                <button id="block-current-site" style="
                    width: 100%;
                    padding: 8px 12px;
                    margin-bottom: 8px;
                    background: #ef4444;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 13px;
                ">Block This Site</button>
                <button id="report-site" style="
                    width: 100%;
                    padding: 8px 12px;
                    margin-bottom: 8px;
                    background: #f59e0b;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 13px;
                ">Report Issue</button>
                <button id="open-settings" style="
                    width: 100%;
                    padding: 8px 12px;
                    background: #4f46e5;
                    color: white;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                    font-size: 13px;
                ">Open Settings</button>
            `;
            
            document.body.appendChild(popup);
            
            // Add event listeners
            document.getElementById('block-current-site').addEventListener('click', () => {
                this.blockCurrentSite();
                popup.remove();
            });
            
            document.getElementById('report-site').addEventListener('click', () => {
                this.reportSite();
                popup.remove();
            });
            
            document.getElementById('open-settings').addEventListener('click', () => {
                this.openExtensionSettings();
                popup.remove();
            });
            
            // Close popup when clicking outside
            setTimeout(() => {
                document.addEventListener('click', (e) => {
                    if (!popup.contains(e.target) && e.target.id !== 'safeguard-indicator') {
                        popup.remove();
                    }
                }, { once: true });
            }, 100);
        }
        
        blockCurrentSite() {
            const currentDomain = window.location.hostname;
            
            // Add to custom blocked domains
            chrome.storage.local.get(['settings'], (data) => {
                const settings = data.settings || { customDomains: [] };
                
                if (!settings.customDomains.includes(currentDomain)) {
                    settings.customDomains.push(currentDomain);
                    
                    chrome.storage.local.set({ settings }, () => {
                        chrome.runtime.sendMessage({ action: 'updateRules' });
                        this.showNotification(`${currentDomain} has been blocked`, 'success');
                        
                        // Redirect to blocked page after short delay
                        setTimeout(() => {
                            window.location.href = chrome.runtime.getURL('blocked.html') + 
                                '?' + new URLSearchParams({
                                    url: window.location.href,
                                    category: 'Manually Blocked'
                                });
                        }, 1500);
                    });
                } else {
                    this.showNotification(`${currentDomain} is already blocked`, 'info');
                }
            });
        }
        
        reportSite() {
            const issue = prompt('Please describe the issue with this site:');
            if (issue) {
                // In a real implementation, this would send to a reporting API
                console.log('Site reported:', {
                    url: window.location.href,
                    domain: window.location.hostname,
                    issue: issue,
                    timestamp: new Date().toISOString()
                });
                
                this.showNotification('Thank you for your report!', 'success');
            }
        }
        
        openExtensionSettings() {
            try {
                chrome.runtime.sendMessage({ action: 'openPopup' });
            } catch (error) {
                console.log('Could not open extension popup');
            }
        }
        
        showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.style.cssText = `
                position: fixed;
                top: 20px;
                right: 20px;
                background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
                color: white;
                padding: 12px 16px;
                border-radius: 8px;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
                font-size: 14px;
                z-index: 10001;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                animation: slideIn 0.3s ease;
            `;
            
            // Add slide-in animation
            const style = document.createElement('style');
            style.textContent = `
                @keyframes slideIn {
                    from { transform: translateX(100%); opacity: 0; }
                    to { transform: translateX(0); opacity: 1; }
                }
            `;
            document.head.appendChild(style);
            
            notification.textContent = message;
            document.body.appendChild(notification);
            
            // Auto-remove after 3 seconds
            setTimeout(() => {
                notification.style.animation = 'slideIn 0.3s ease reverse';
                setTimeout(() => {
                    notification.remove();
                    style.remove();
                }, 300);
            }, 3000);
        }
        
        // Monitor for dynamically loaded content
        monitorDynamicContent() {
            // Set up MutationObserver to watch for new content
            const observer = new MutationObserver((mutations) => {
                mutations.forEach((mutation) => {
                    if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                        // Check if new content contains blocked keywords
                        mutation.addedNodes.forEach((node) => {
                            if (node.nodeType === Node.ELEMENT_NODE) {
                                this.checkNewContent(node);
                            }
                        });
                    }
                });
            });
            
            observer.observe(document.body, {
                childList: true,
                subtree: true
            });
        }
        
        checkNewContent(element) {
            // Check new content for inappropriate material
            const text = element.textContent || '';
            
            chrome.storage.local.get(['settings'], (data) => {
                if (data.settings && data.settings.blockedKeywords) {
                    const foundKeywords = data.settings.blockedKeywords.filter(keyword => 
                        text.toLowerCase().includes(keyword.toLowerCase())
                    );
                    
                    if (foundKeywords.length > 0) {
                        // Hide or blur the problematic content
                        element.style.filter = 'blur(5px)';
                        element.style.cursor = 'pointer';
                        element.title = 'Content hidden by SafeGuard. Click to reveal.';
                        
                        element.addEventListener('click', () => {
                            if (confirm('This content was hidden by SafeGuard. Are you sure you want to view it?')) {
                                element.style.filter = 'none';
                                element.style.cursor = 'auto';
                                element.title = '';
                            }
                        });
                    }
                }
            });
        }
    }
    
    // Initialize content script
    const safeguardContent = new SafeGuardContent();
    
    // Listen for messages from background script
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        switch (message.action) {
            case 'checkPageContent':
                sendResponse({
                    url: window.location.href,
                    title: document.title,
                    domain: window.location.hostname
                });
                break;
                
            case 'showWarning':
                safeguardContent.showNotification(message.message, 'warning');
                break;
                
            case 'hideContent':
                document.body.style.display = 'none';
                break;
        }
    });
    
    console.log('SafeGuard content script initialized');
})();