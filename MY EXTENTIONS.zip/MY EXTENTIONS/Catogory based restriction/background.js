// Default data structures
const defaultCategories = [
    { 
        id: 'adult', 
        name: 'Adult Content', 
        description: 'Blocks adult and mature content', 
        icon: '🔞', 
        blocked: false, 
        domains: ["pornhub.com", "xvideos.com", "xnxx.com", "redtube.com", "youporn.com"] 
    },
    { 
        id: 'gambling', 
        name: 'Gambling', 
        description: 'Blocks betting and casino sites', 
        icon: '🎲', 
        blocked: false, 
        domains: ["bet365.com", "betway.com", "pokerstars.com", "bet9ja.com", "nairabet.com"] 
    },
    { 
        id: 'social', 
        name: 'Social Media', 
        description: 'Blocks social networking platforms', 
        icon: '📱', 
        blocked: false, 
        domains: ["facebook.com", "twitter.com", "instagram.com", "tiktok.com", "snapchat.com"] 
    },
    { 
        id: 'dating', 
        name: 'Dating Sites', 
        description: 'Blocks dating and relationship sites', 
        icon: '💕', 
        blocked: false, 
        domains: ["tinder.com", "badoo.com", "bumble.com", "okcupid.com", "match.com"] 
    },
    { 
        id: 'violent', 
        name: 'Violent Content', 
        description: 'Blocks violent and disturbing content', 
        icon: '⚔️', 
        blocked: false, 
        domains: ["bestgore.com", "liveleak.com", "goregrish.com", "theync.com"] 
    },
    { 
        id: 'misinformation', 
        name: 'Misinformation', 
        description: 'Blocks known misinformation sources', 
        icon: '❌', 
        blocked: false, 
        domains: ["infowars.com", "breitbart.com", "naturalnews.com"] 
    },
    { 
        id: 'scams', 
        name: 'Scams & Fraud', 
        description: 'Blocks fraudulent websites', 
        icon: '🚨', 
        blocked: false, 
        domains: ["quicknaijajobs.com", "instantcashjobz.com", "getrichnaija.com"] 
    }
];

const defaultProfiles = [
    { 
        id: 'default', 
        name: 'Default', 
        description: 'Standard protection', 
        active: true, 
        restrictions: [] 
    },
    { 
        id: 'child', 
        name: 'Child Mode', 
        description: 'Maximum protection for children', 
        active: false, 
        restrictions: ['adult', 'gambling', 'violent', 'dating'] 
    },
    { 
        id: 'work', 
        name: 'Work Mode', 
        description: 'Focus on productivity', 
        active: false, 
        restrictions: ['social', 'gambling'] 
    }
];

const defaultSettings = {
    overridePin: '1234',
    customDomains: [],
    blockingEnabled: true
};

const defaultStats = {
    totalBlocked: 0,
    totalAttempts: 0,
    activeDays: 1,
    categoryStats: {},
    lastActive: new Date().toISOString().split('T')[0]
};

// Initialize extension
chrome.runtime.onInstalled.addListener(async () => {
    console.log('SafeGuard extension installed/updated');
    
    const data = await chrome.storage.local.get(['categories', 'profiles', 'settings', 'schedules', 'stats']);
    
    // Initialize default data if not exists
    const updates = {};
    if (!data.categories) updates.categories = defaultCategories;
    if (!data.profiles) updates.profiles = defaultProfiles;
    if (!data.settings) updates.settings = defaultSettings;
    if (!data.schedules) updates.schedules = [];
    if (!data.stats) updates.stats = defaultStats;
    
    if (Object.keys(updates).length > 0) {
        await chrome.storage.local.set(updates);
        console.log('Default data initialized');
    }
    
    // Apply initial blocking rules
    await updateBlockingRules();
    
    // Set up scheduled checks
    setupScheduleAlarms();
});

// Update blocking rules using declarativeNetRequest API
async function updateBlockingRules() {
    try {
        const { categories, settings } = await chrome.storage.local.get(['categories', 'settings']);
        
        if (!categories || !settings) return;
        
        // Get all domains to block
        const blockedDomains = [];
        
        // Add category domains
        categories.forEach(category => {
            if (category.blocked && category.domains) {
                blockedDomains.push(...category.domains);
            }
        });
        
        // Add custom domains
        if (settings.customDomains) {
            blockedDomains.push(...settings.customDomains);
        }
        
        // Remove duplicates
        const uniqueDomains = [...new Set(blockedDomains)];
        
        // Clear existing rules
        const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
        const existingRuleIds = existingRules.map(rule => rule.id);
        
        // Create new rules
        const newRules = [];
        uniqueDomains.forEach((domain, index) => {
            if (domain.trim()) {
                newRules.push({
                    id: index + 1,
                    priority: 1,
                    action: {
                        type: 'redirect',
                        redirect: { 
                            extensionPath: '/blocked.html?' + new URLSearchParams({
                                url: domain,
                                category: 'Blocked Category'
                            }).toString()
                        }
                    },
                    condition: {
                        urlFilter: `*://*.${domain.replace(/^\./, '')}/*`,
                        resourceTypes: ['main_frame']
                    }
                });
            }
        });
        
        // Update rules
        await chrome.declarativeNetRequest.updateDynamicRules({
            removeRuleIds: existingRuleIds,
            addRules: newRules
        });
        
        console.log(`Updated blocking rules: ${newRules.length} domains blocked`);
        
    } catch (error) {
        console.error('Error updating blocking rules:', error);
    }
}

// Schedule management
function setupScheduleAlarms() {
    // Clear existing alarms
    chrome.alarms.clearAll();
    
    // Create alarm to check schedules every minute
    chrome.alarms.create('checkSchedules', { 
        delayInMinutes: 1, 
        periodInMinutes: 1 
    });
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === 'checkSchedules') {
        await checkScheduledRestrictions();
    }
});

async function checkScheduledRestrictions() {
    try {
        const { schedules, profiles, categories } = await chrome.storage.local.get(['schedules', 'profiles', 'categories']);
        
        if (!schedules || schedules.length === 0) return;
        
        const now = new Date();
        const currentDay = now.getDay(); // 0 = Sunday, 1 = Monday, etc.
        const currentTime = now.toTimeString().slice(0, 5); // HH:MM format
        
        let shouldUpdateRules = false;
        let activeScheduleFound = false;
        
        // Check each schedule
        for (const schedule of schedules) {
            if (!schedule.enabled) continue;
            
            const isScheduledDay = schedule.days.includes(currentDay);
            const isInTimeRange = currentTime >= schedule.startTime && currentTime < schedule.endTime;
            
            if (isScheduledDay && isInTimeRange) {
                // Activate the scheduled profile
                const targetProfile = profiles.find(p => p.id === schedule.profileId);
                if (targetProfile && !targetProfile.active) {
                    // Deactivate all profiles
                    profiles.forEach(p => p.active = false);
                    // Activate target profile
                    targetProfile.active = true;
                    
                    // Apply profile restrictions
                    categories.forEach(cat => {
                        cat.blocked = targetProfile.restrictions.includes(cat.id);
                    });
                    
                    shouldUpdateRules = true;
                    activeScheduleFound = true;
                    
                    console.log(`Activated scheduled profile: ${targetProfile.name}`);
                    break;
                }
            }
        }
        
        // If no active schedule and we're not on default profile, switch to default
        if (!activeScheduleFound) {
            const defaultProfile = profiles.find(p => p.id === 'default');
            const currentActiveProfile = profiles.find(p => p.active);
            
            if (defaultProfile && currentActiveProfile && currentActiveProfile.id !== 'default') {
                // Switch to default profile
                profiles.forEach(p => p.active = p.id === 'default');
                
                // Apply default restrictions (usually none)
                categories.forEach(cat => {
                    cat.blocked = defaultProfile.restrictions.includes(cat.id);
                });
                
                shouldUpdateRules = true;
                console.log('Switched back to default profile');
            }
        }
        
        // Save changes and update rules if needed
        if (shouldUpdateRules) {
            await chrome.storage.local.set({ profiles, categories });
            await updateBlockingRules();
        }
        
    } catch (error) {
        console.error('Error checking scheduled restrictions:', error);
    }
}

// Handle messages from popup and content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    switch (message.action) {
        case 'updateRules':
            updateBlockingRules().then(() => {
                sendResponse({ success: true });
            }).catch(error => {
                console.error('Error updating rules:', error);
                sendResponse({ success: false, error: error.message });
            });
            return true; // Keep message channel open for async response
            
        case 'getStats':
            chrome.storage.local.get(['stats']).then(data => {
                sendResponse(data.stats || defaultStats);
            });
            return true;
            
        case 'updateStats':
            updateStats(message.data).then(() => {
                sendResponse({ success: true });
            });
            return true;
            
        case 'checkOverride':
            handleOverrideCheck(message.pin, message.url).then(result => {
                sendResponse(result);
            });
            return true;
    }
});

// Statistics management
async function updateStats(data) {
    try {
        const { stats } = await chrome.storage.local.get(['stats']);
        const currentStats = stats || defaultStats;
        
        // Update stats
        if (data.blocked) {
            currentStats.totalBlocked++;
            currentStats.totalAttempts++;
            
            // Update category stats
            if (data.category) {
                currentStats.categoryStats[data.category] = (currentStats.categoryStats[data.category] || 0) + 1;
            }
        }
        
        // Check if it's a new day
        const today = new Date().toISOString().split('T')[0];
        if (currentStats.lastActive !== today) {
            currentStats.activeDays++;
            currentStats.lastActive = today;
        }
        
        await chrome.storage.local.set({ stats: currentStats });
        
    } catch (error) {
        console.error('Error updating stats:', error);
    }
}

// Override system
async function handleOverrideCheck(pin, url) {
    try {
        const { settings } = await chrome.storage.local.get(['settings']);
        
        if (settings && settings.overridePin === pin) {
            // Grant temporary access
            console.log(`Override granted for: ${url}`);
            return { success: true, message: 'Access granted' };
        } else {
            return { success: false, message: 'Invalid PIN' };
        }
        
    } catch (error) {
        console.error('Error checking override:', error);
        return { success: false, message: 'Override check failed' };
    }
}

// Tab management for statistics
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    if (changeInfo.status === 'complete' && tab.url) {
        // Check if this URL would be blocked
        const { categories } = await chrome.storage.local.get(['categories']);
        
        if (categories) {
            const blockedDomains = categories
                .filter(cat => cat.blocked)
                .flatMap(cat => cat.domains || []);
                
            const currentDomain = new URL(tab.url).hostname;
            const isBlocked = blockedDomains.some(domain => 
                currentDomain.includes(domain.replace(/^\./, ''))
            );
            
            if (isBlocked) {
                // This would be blocked, update stats
                await updateStats({ 
                    blocked: true, 
                    category: 'unknown',
                    url: tab.url 
                });
            }
        }
    }
});

console.log('SafeGuard background script loaded');