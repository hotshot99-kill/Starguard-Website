// Background Service Worker for Advanced Ad Blocker Pro

class AdBlockerBackground {
  constructor() {
    this.stats = {
      totalBlocked: 0,
      todayBlocked: 0,
      weekBlocked: 0,
      monthBlocked: 0,
      domainStats: {},
      lastResetDate: new Date().toDateString()
    };
    this.filterLists = {
      easylist: 'https://easylist.to/easylist/easylist.txt',
      easyprivacy: 'https://easylist.to/easylist/easyprivacy.txt',
      fanboy: 'https://easylist.to/easylist/fanboy-annoyance.txt',
      ublock: 'https://raw.githubusercontent.com/uBlockOrigin/uAssets/master/filters/filters.txt'
    };
    this.init();
  }

  async init() {
    // Load saved stats
    const saved = await chrome.storage.local.get(['adblockStats']);
    if (saved.adblockStats) {
      this.stats = { ...this.stats, ...saved.adblockStats };
      this.resetStatsIfNeeded();
    }

    // Set up periodic filter updates
    chrome.alarms.create('updateFilters', { periodInMinutes: 1440 }); // 24 hours
    chrome.alarms.onAlarm.addListener(this.handleAlarm.bind(this));

    // Listen for web requests
    chrome.webRequest.onBeforeRequest.addListener(
      this.blockRequest.bind(this),
      { urls: ['<all_urls>'] },
      ['blocking']
    );

    // Update badge on tab changes
    chrome.tabs.onActivated.addListener(this.updateBadge.bind(this));
    chrome.tabs.onUpdated.addListener(this.updateBadge.bind(this));

    // Initial filter update
    this.updateAllFilters();
  }

  resetStatsIfNeeded() {
    const today = new Date().toDateString();
    if (this.stats.lastResetDate !== today) {
      // Reset daily stats
      this.stats.todayBlocked = 0;
      
      // Reset weekly stats (if it's Monday)
      if (new Date().getDay() === 1) {
        this.stats.weekBlocked = 0;
      }
      
      // Reset monthly stats (if it's the 1st)
      if (new Date().getDate() === 1) {
        this.stats.monthBlocked = 0;
      }
      
      this.stats.lastResetDate = today;
      this.saveStats();
    }
  }

  async handleAlarm(alarm) {
    if (alarm.name === 'updateFilters') {
      await this.updateAllFilters();
    }
  }

  async updateAllFilters() {
    console.log('Updating filter lists...');
    const settings = await chrome.storage.local.get(['settings']);
    const userSettings = settings.settings || { blockingLevel: 'balanced' };

    try {
      for (const [name, url] of Object.entries(this.filterLists)) {
        await this.updateFilterList(name, url);
      }
      console.log('Filter lists updated successfully');
    } catch (error) {
      console.error('Failed to update filter lists:', error);
    }
  }

  async updateFilterList(name, url) {
    try {
      const response = await fetch(url);
      const filterText = await response.text();
      const rules = this.parseFilterList(filterText);
      
      await chrome.storage.local.set({ [`filters_${name}`]: rules });
      console.log(`Updated ${name} filter list with ${rules.length} rules`);
    } catch (error) {
      console.error(`Failed to update ${name}:`, error);
    }
  }

  parseFilterList(filterText) {
    const rules = [];
    const lines = filterText.split('\n');
    
    for (let line of lines) {
      line = line.trim();
      if (line && !line.startsWith('!') && !line.startsWith('[')) {
        // Basic filter parsing - simplified for demo
        if (line.includes('||') || line.includes('###') || line.includes('##.')) {
          rules.push(line);
        }
      }
    }
    
    return rules;
  }

  async blockRequest(details) {
    const url = details.url;
    const tabId = details.tabId;
    
    // Skip chrome:// and extension pages
    if (url.startsWith('chrome://') || url.startsWith('chrome-extension://')) {
      return {};
    }

    // Check if request should be blocked
    const shouldBlock = await this.shouldBlockRequest(url, details.type);
    
    if (shouldBlock) {
      this.incrementBlockedCount(tabId, url);
      return { cancel: true };
    }
    
    return {};
  }

  async shouldBlockRequest(url, type) {
    // Load all filter lists
    const storage = await chrome.storage.local.get();
    const settings = storage.settings || { blockingLevel: 'balanced' };
    
    // Check against loaded filters
    for (const key of Object.keys(storage)) {
      if (key.startsWith('filters_')) {
        const filters = storage[key] || [];
        for (const filter of filters) {
          if (this.matchesFilter(url, filter, type)) {
            return true;
          }
        }
      }
    }

    // Heuristic detection
    return this.heuristicDetection(url, type);
  }

  matchesFilter(url, filter, type) {
    // Simplified filter matching - in production, use more robust parsing
    if (filter.includes('||')) {
      const domain = filter.replace('||', '').split('/')[0];
      return url.includes(domain);
    }
    
    if (filter.includes('*')) {
      const pattern = filter.replace(/\*/g, '.*');
      const regex = new RegExp(pattern);
      return regex.test(url);
    }
    
    return url.includes(filter);
  }

  heuristicDetection(url, type) {
    const adPatterns = [
      /ads?\.|\.ads\.|doubleclick|googleads|googlesyndication|amazon-adsystem/i,
      /adsystem|adnxs|adscdn|adform|outbrain|taboola|criteo/i,
      /facebook\.com\/tr|google-analytics|googletagmanager/i,
      /\/ads\/|\/ad\/|\/advertisement|\/sponsored/i,
      /popup|popunder|interstitial/i
    ];

    return adPatterns.some(pattern => pattern.test(url));
  }

  async incrementBlockedCount(tabId, url) {
    if (tabId === -1) return;

    this.stats.totalBlocked++;
    this.stats.todayBlocked++;
    this.stats.weekBlocked++;
    this.stats.monthBlocked++;

    // Track domain stats
    try {
      const domain = new URL(url).hostname;
      this.stats.domainStats[domain] = (this.stats.domainStats[domain] || 0) + 1;
    } catch (e) {}

    // Update tab-specific count
    const tabData = await chrome.storage.session.get([`tab_${tabId}`]);
    const count = (tabData[`tab_${tabId}`] || 0) + 1;
    await chrome.storage.session.set({ [`tab_${tabId}`]: count });

    // Update badge
    chrome.action.setBadgeText({ 
      tabId: tabId, 
      text: count.toString() 
    });
    chrome.action.setBadgeBackgroundColor({ 
      tabId: tabId, 
      color: '#FF4444' 
    });

    // Show notification popup
    this.showBlockedNotification(tabId, url);

    // Save stats
    this.saveStats();
  }

  async showBlockedNotification(tabId, url) {
    try {
      const domain = new URL(url).hostname;
      chrome.scripting.executeScript({
        target: { tabId: tabId },
        func: this.createNotificationPopup,
        args: [domain]
      });
    } catch (e) {}
  }

  createNotificationPopup(domain) {
    // This function runs in content script context
    const existingPopup = document.getElementById('adblock-notification');
    if (existingPopup) {
      existingPopup.remove();
    }

    const popup = document.createElement('div');
    popup.id = 'adblock-notification';
    popup.style.cssText = `
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #2d3748;
      color: white;
      padding: 12px 16px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 14px;
      display: flex;
      align-items: center;
      gap: 8px;
      animation: slideIn 0.3s ease-out;
    `;

    popup.innerHTML = `
      <div style="width: 16px; height: 16px; background: #48bb78; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px;">✓</div>
      <span>Blocked ad from ${domain}</span>
    `;

    // Add CSS animation
    if (!document.getElementById('adblock-styles')) {
      const style = document.createElement('style');
      style.id = 'adblock-styles';
      style.textContent = `
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
      `;
      document.head.appendChild(style);
    }

    document.body.appendChild(popup);

    // Remove after 3 seconds
    setTimeout(() => {
      popup.style.animation = 'slideIn 0.3s ease-out reverse';
      setTimeout(() => popup.remove(), 300);
    }, 3000);
  }

  async updateBadge(activeInfo) {
    const tabId = activeInfo.tabId || activeInfo.activeTabId;
    if (!tabId) return;

    const tabData = await chrome.storage.session.get([`tab_${tabId}`]);
    const count = tabData[`tab_${tabId}`] || 0;
    
    chrome.action.setBadgeText({ 
      tabId: tabId, 
      text: count > 0 ? count.toString() : '' 
    });
  }

  async saveStats() {
    await chrome.storage.local.set({ adblockStats: this.stats });
  }

  // API for popup to get stats
  async getStats() {
    return this.stats;
  }

  async getTopBlockedDomains(limit = 10) {
    const sorted = Object.entries(this.stats.domainStats)
      .sort(([,a], [,b]) => b - a)
      .slice(0, limit);
    return sorted;
  }
}

// Initialize
const adBlocker = new AdBlockerBackground();

// Message handling for popup communication
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case 'getStats':
      adBlocker.getStats().then(sendResponse);
      return true;
    case 'getTopDomains':
      adBlocker.getTopBlockedDomains(request.limit).then(sendResponse);
      return true;
    case 'updateFilters':
      adBlocker.updateAllFilters().then(() => sendResponse({ success: true }));
      return true;
  }
});

// Export for extension pages
globalThis.adBlocker = adBlocker;