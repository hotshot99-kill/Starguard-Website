// Popup JavaScript for Advanced Ad Blocker Pro

class PopupController {
  constructor() {
    this.currentTab = null;
    this.settings = {
      blockingLevel: 'balanced',
      stealthMode: true,
      heuristicDetection: true,
      socialWidgets: false
    };
    this.init();
  }

  async init() {
    await this.getCurrentTab();
    await this.loadSettings();
    await this.loadStats();
    this.setupEventListeners();
    this.updateUI();
  }

  async getCurrentTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    this.currentTab = tab;
  }

  async loadSettings() {
    const result = await chrome.storage.local.get(['settings']);
    if (result.settings) {
      this.settings = { ...this.settings, ...result.settings };
    }
  }

  async loadStats() {
    try {
      this.stats = await this.sendMessage({ action: 'getStats' });
      this.topDomains = await this.sendMessage({ action: 'getTopDomains', limit: 5 });
    } catch (error) {
      console.error('Failed to load stats:', error);
      this.stats = {
        totalBlocked: 0,
        todayBlocked: 0,
        weekBlocked: 0,
        monthBlocked: 0
      };
      this.topDomains = [];
    }
  }

  sendMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          reject(chrome.runtime.lastError);
        } else {
          resolve(response);
        }
      });
    });
  }

  async updateUI() {
    await this.updateCurrentPageInfo();
    this.updateStats();
    this.updateTopDomains();
    this.updatePrivacyScore();
    this.updateRecommendations();
    this.updateBlockingLevel();
    this.updateSettings();
  }

  async updateCurrentPageInfo() {
    if (!this.currentTab) return;

    const domain = new URL(this.currentTab.url).hostname;
    document.getElementById('currentDomain').textContent = domain;

    // Get page-specific blocked count
    try {
      const tabData = await chrome.storage.session.get([`tab_${this.currentTab.id}`]);
      const pageCount = tabData[`tab_${this.currentTab.id}`] || 0;
      document.getElementById('pageBlockedCount').textContent = pageCount;
    } catch (error) {
      document.getElementById('pageBlockedCount').textContent = '0';
    }
  }

  updateStats() {
    if (!this.stats) return;

    document.getElementById('todayBlocked').textContent = this.stats.todayBlocked || 0;
    document.getElementById('weekBlocked').textContent = this.stats.weekBlocked || 0;
    document.getElementById('monthBlocked').textContent = this.stats.monthBlocked || 0;
    document.getElementById('totalBlocked').textContent = this.stats.totalBlocked || 0;
  }

  updateTopDomains() {
    const container = document.getElementById('topDomains');
    container.innerHTML = '';

    if (!this.topDomains || this.topDomains.length === 0) {
      container.innerHTML = '<p style="color: #718096; font-size: 13px; text-align: center;">No blocked domains yet</p>';
      return;
    }

    this.topDomains.forEach(([domain, count]) => {
      const item = document.createElement('div');
      item.className = 'domain-item';
      item.innerHTML = `
        <span class="domain-name">${domain}</span>
        <span class="domain-count">${count}</span>
      `;
      container.appendChild(item);
    });
  }

  updatePrivacyScore() {
    // Calculate privacy score based on various factors
    let score = 60; // Base score

    // Add points for blocking level
    switch (this.settings.blockingLevel) {
      case 'aggressive': score += 25; break;
      case 'balanced': score += 15; break;
      case 'minimal': score += 5; break;
    }

    // Add points for enabled features
    if (this.settings.stealthMode) score += 10;
    if (this.settings.heuristicDetection) score += 10;
    if (this.settings.socialWidgets) score += 5;

    // Add points based on blocking activity
    const blockedToday = this.stats?.todayBlocked || 0;
    if (blockedToday > 0) score += Math.min(10, blockedToday / 5);

    score = Math.min(100, Math.max(0, Math.round(score)));
    
    const scoreElement = document.getElementById('privacyScore');
    const scoreValue = scoreElement.querySelector('.score-value');
    scoreValue.textContent = `${score}%`;
    
    // Color coding
    if (score >= 80) {
      scoreValue.style.color = '#48bb78';
    } else if (score >= 60) {
      scoreValue.style.color = '#ed8936';
    } else {
      scoreValue.style.color = '#e53e3e';
    }
  }

  updateRecommendations() {
    const container = document.getElementById('recommendations');
    container.innerHTML = '';

    const recommendations = [];

    // Generate recommendations based on current settings
    if (!this.settings.stealthMode) {
      recommendations.push({
        type: 'warning',
        text: 'Enable Stealth Mode to avoid ad blocker detection'
      });
    }

    if (this.settings.blockingLevel === 'minimal') {
      recommendations.push({
        type: 'info',
        text: 'Consider using Balanced mode for better privacy protection'
      });
    }

    if (!this.settings.heuristicDetection) {
      recommendations.push({
        type: 'info',
        text: 'Enable Smart Detection to catch more ads and trackers'
      });
    }

    const blockedToday = this.stats?.todayBlocked || 0;
    if (blockedToday === 0) {
      recommendations.push({
        type: 'info',
        text: 'Browse some websites to see blocking in action'
      });
    }

    // Add performance recommendation
    if (blockedToday > 50) {
      recommendations.push({
        type: 'info',
        text: `Great! You've saved bandwidth by blocking ${blockedToday} requests today`
      });
    }

    if (recommendations.length === 0) {
      recommendations.push({
        type: 'info',
        text: 'Your privacy setup looks good! Keep browsing safely.'
      });
    }

    recommendations.forEach(rec => {
      const item = document.createElement('div');
      item.className = `recommendation ${rec.type}`;
      item.innerHTML = `
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
          ${rec.type === 'warning' ? 
            '<path d="M12 9V13M12 17H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>' :
            '<path d="M13 16H12V12H11M12 8H12.01M21 12C21 16.9706 16.9706 21 12 21C7.02944 21 3 16.9706 3 12C3 7.02944 7.02944 3 12 3C16.9706 3 21 7.02944 21 12Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>'
          }
        </svg>
        <span>${rec.text}</span>
      `;
      container.appendChild(item);
    });
  }

  updateBlockingLevel() {
    const levels = document.querySelectorAll('input[name="blockingLevel"]');
    levels.forEach(radio => {
      radio.checked = radio.value === this.settings.blockingLevel;
    });
    this.updateLevelDescription();
  }

  updateLevelDescription() {
    const descriptions = {
      minimal: 'Blocks only intrusive ads, allows acceptable ads',
      balanced: 'Blocks most ads while allowing non-intrusive ones',
      aggressive: 'Blocks all ads, social widgets, and sponsored content'
    };
    
    document.getElementById('levelDescription').textContent = 
      descriptions[this.settings.blockingLevel];
  }

  updateSettings() {
    document.getElementById('stealthMode').checked = this.settings.stealthMode;
    document.getElementById('heuristicDetection').checked = this.settings.heuristicDetection;
    document.getElementById('socialWidgets').checked = this.settings.socialWidgets;
  }

  setupEventListeners() {
    // Element picker
    document.getElementById('elementPicker').addEventListener('click', async () => {
      try {
        await chrome.tabs.sendMessage(this.currentTab.id, { action: 'toggleElementPicker' });
        window.close();
      } catch (error) {
        console.error('Failed to activate element picker:', error);
      }
    });

    // Whitelist site
    document.getElementById('whitelistSite').addEventListener('click', async () => {
      await this.toggleWhitelist();
    });

    // Update filters
    document.getElementById('updateFilters').addEventListener('click', async () => {
      const button = document.getElementById('updateFilters');
      button.textContent = 'Updating...';
      button.disabled = true;
      
      try {
        await this.sendMessage({ action: 'updateFilters' });
        button.textContent = 'Updated!';
        setTimeout(() => {
          button.textContent = 'Update Filters';
          button.disabled = false;
        }, 2000);
      } catch (error) {
        button.textContent = 'Failed';
        setTimeout(() => {
          button.textContent = 'Update Filters';
          button.disabled = false;
        }, 2000);
      }
    });

    // Blocking level changes
    document.querySelectorAll('input[name="blockingLevel"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.settings.blockingLevel = e.target.value;
        this.saveSettings();
        this.updateLevelDescription();
        this.updatePrivacyScore();
        this.updateRecommendations();
      });
    });

    // Settings toggles
    document.getElementById('stealthMode').addEventListener('change', (e) => {
      this.settings.stealthMode = e.target.checked;
      this.saveSettings();
      this.updatePrivacyScore();
      this.updateRecommendations();
    });

    document.getElementById('heuristicDetection').addEventListener('change', (e) => {
      this.settings.heuristicDetection = e.target.checked;
      this.saveSettings();
      this.updatePrivacyScore();
      this.updateRecommendations();
    });

    document.getElementById('socialWidgets').addEventListener('change', (e) => {
      this.settings.socialWidgets = e.target.checked;
      this.saveSettings();
      this.updatePrivacyScore();
      this.updateRecommendations();
    });

    // Advanced settings
    document.getElementById('viewSettings').addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });
  }

  async toggleWhitelist() {
    if (!this.currentTab) return;

    const domain = new URL(this.currentTab.url).hostname;
    const button = document.getElementById('whitelistSite');
    
    try {
      // Get current whitelist
      const result = await chrome.storage.local.get(['whitelist']);
      const whitelist = result.whitelist || [];
      
      const isWhitelisted = whitelist.includes(domain);
      
      if (isWhitelisted) {
        // Remove from whitelist
        const newWhitelist = whitelist.filter(d => d !== domain);
        await chrome.storage.local.set({ whitelist: newWhitelist });
        button.textContent = '✓ Removed from Whitelist';
        button.style.background = '#e53e3e';
      } else {
        // Add to whitelist
        whitelist.push(domain);
        await chrome.storage.local.set({ whitelist });
        button.textContent = '✓ Added to Whitelist';
        button.style.background = '#48bb78';
      }
      
      // Reset button after 2 seconds
      setTimeout(() => {
        button.textContent = isWhitelisted ? 'Whitelist Site' : 'Remove from Whitelist';
        button.style.background = '';
      }, 2000);
      
    } catch (error) {
      console.error('Failed to toggle whitelist:', error);
      button.textContent = 'Error';
      setTimeout(() => {
        button.textContent = 'Whitelist Site';
      }, 2000);
    }
  }

  async saveSettings() {
    await chrome.storage.local.set({ settings: this.settings });
    
    // Send updated settings to content scripts
    try {
      await chrome.tabs.sendMessage(this.currentTab.id, { 
        action: 'updateSettings', 
        settings: this.settings 
      });
    } catch (error) {
      // Content script might not be loaded, ignore error
    }
  }

  // Utility method to format numbers
  formatNumber(num) {
    if (num >= 1000000) {
      return (num / 1000000).toFixed(1) + 'M';
    } else if (num >= 1000) {
      return (num / 1000).toFixed(1) + 'K';
    }
    return num.toString();
  }

  // Add visual feedback for user actions
  showFeedback(element, message, type = 'success') {
    const feedback = document.createElement('div');
    feedback.style.cssText = `
      position: absolute;
      top: -30px;
      left: 50%;
      transform: translateX(-50%);
      background: ${type === 'success' ? '#48bb78' : '#e53e3e'};
      color: white;
      padding: 6px 12px;
      border-radius: 4px;
      font-size: 12px;
      white-space: nowrap;
      z-index: 1000;
      opacity: 0;
      transition: opacity 0.3s;
    `;
    feedback.textContent = message;
    
    element.style.position = 'relative';
    element.appendChild(feedback);
    
    setTimeout(() => feedback.style.opacity = '1', 10);
    setTimeout(() => {
      feedback.style.opacity = '0';
      setTimeout(() => feedback.remove(), 300);
    }, 2000);
  }
}

// Initialize popup when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  new PopupController();
});

// Handle popup reopening (update stats)
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    // Refresh data when popup becomes visible
    setTimeout(() => {
      new PopupController();
    }, 100);
  }
});