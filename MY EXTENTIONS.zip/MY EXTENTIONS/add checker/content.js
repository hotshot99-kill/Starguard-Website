// Content Script for Advanced Ad Blocker Pro

class ContentScriptBlocker {
  constructor() {
    this.observer = null;
    this.elementPicker = null;
    this.isPickerActive = false;
    this.blockedElements = new Set();
    this.stealthMode = true;
    this.init();
  }

  async init() {
    // Load settings
    const settings = await chrome.storage.local.get(['settings']);
    this.settings = settings.settings || {
      blockingLevel: 'balanced',
      stealthMode: true,
      elementPicker: true,
      heuristicDetection: true
    };

    // Inject stealth script immediately
    if (this.settings.stealthMode) {
      this.injectStealthScript();
    }

    // Start blocking when DOM is ready
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', () => this.startBlocking());
    } else {
      this.startBlocking();
    }

    // Listen for messages from popup
    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this));
  }

  injectStealthScript() {
    const script = document.createElement('script');
    script.src = chrome.runtime.getURL('stealth.js');
    (document.head || document.documentElement).appendChild(script);
    script.onload = () => script.remove();
  }

  startBlocking() {
    // Initial DOM scan
    this.scanAndBlockElements();

    // Set up mutation observer for dynamic content
    this.setupMutationObserver();

    // Override common ad functions
    this.overrideAdFunctions();

    // Set up element picker if enabled
    if (this.settings.elementPicker) {
      this.setupElementPicker();
    }
  }

  scanAndBlockElements() {
    const selectors = this.getBlockingSelectors();
    
    selectors.forEach(selector => {
      try {
        const elements = document.querySelectorAll(selector);
        elements.forEach(el => this.blockElement(el, 'css-selector'));
      } catch (e) {
        // Invalid selector, skip
      }
    });

    // Heuristic detection
    if (this.settings.heuristicDetection) {
      this.performHeuristicDetection();
    }
  }

  getBlockingSelectors() {
    const base = [
      // Common ad containers
      '[id*="ad"]:not([id*="address"]):not([id*="badge"]):not([id*="thread"]):not([id*="head"])',
      '[class*="ad"]:not([class*="address"]):not([class*="badge"]):not([class*="thread"]):not([class*="head"])',
      '[id*="sponsor"]', '[class*="sponsor"]',
      '[id*="popup"]', '[class*="popup"]',
      '[id*="banner"]', '[class*="banner"]',
      
      // Specific ad networks
      '.adsbygoogle',
      '.amazon-ad',
      '.outbrain-widget',
      '.taboola-widget',
      '.criteo-ad',
      
      // Social media widgets
      '.fb-like', '.twitter-tweet', '.instagram-media',
      
      // Tracking pixels
      'img[width="1"][height="1"]',
      'img[style*="width:1px"]',
      
      // Common ad iframes
      'iframe[src*="doubleclick"]',
      'iframe[src*="googleads"]',
      'iframe[src*="amazon-adsystem"]'
    ];

    const aggressive = [
      ...base,
      '[id*="promo"]', '[class*="promo"]',
      '[id*="affiliate"]', '[class*="affiliate"]',
      '.sidebar-ad', '.header-ad', '.footer-ad',
      '.social-share', '.social-buttons'
    ];

    return this.settings.blockingLevel === 'aggressive' ? aggressive : base;
  }

  performHeuristicDetection() {
    // Check for suspicious patterns
    const elements = document.querySelectorAll('*');
    
    elements.forEach(el => {
      if (this.isLikelyAd(el)) {
        this.blockElement(el, 'heuristic');
      }
    });
  }

  isLikelyAd(element) {
    const { tagName, className, id, style, textContent } = element;
    
    // Size-based detection
    const rect = element.getBoundingClientRect();
    const commonAdSizes = [
      [728, 90], [300, 250], [336, 280], [320, 50], [970, 250]
    ];
    
    const matchesAdSize = commonAdSizes.some(([w, h]) => 
      Math.abs(rect.width - w) < 10 && Math.abs(rect.height - h) < 10
    );

    // Text-based detection
    const suspiciousText = /sponsored|advertisement|promoted|ad\s*choice|close\s*ad/i;
    const hasAdText = suspiciousText.test(textContent);

    // Attribute-based detection
    const adPatterns = /ad|sponsor|promo|banner|popup/i;
    const hasAdAttributes = adPatterns.test(className + id);

    // Style-based detection
    const hasAdStyles = style && (
      style.position === 'fixed' && 
      (style.zIndex > 1000 || style.top === '0px')
    );

    return matchesAdSize || hasAdText || hasAdAttributes || hasAdStyles;
  }

  blockElement(element, reason) {
    if (this.blockedElements.has(element)) return;
    
    this.blockedElements.add(element);
    
    // Hide the element
    element.style.setProperty('display', 'none', 'important');
    element.style.setProperty('visibility', 'hidden', 'important');
    element.style.setProperty('opacity', '0', 'important');
    element.style.setProperty('height', '0', 'important');
    element.style.setProperty('width', '0', 'important');
    
    // Clean up parent if it becomes empty
    this.cleanupEmptyContainers(element.parentElement);
    
    // Add to blocked count
    this.reportBlockedElement(element.src || element.href || 'DOM element', reason);
  }

  cleanupEmptyContainers(container) {
    if (!container || container === document.body) return;
    
    // Remove empty containers that likely held ads
    const isEmpty = !container.textContent.trim() && 
                   container.children.length === 0;
    
    const isAdContainer = /ad|sponsor|banner/i.test(container.className + container.id);
    
    if (isEmpty && isAdContainer) {
      container.style.setProperty('display', 'none', 'important');
    }
  }

  setupMutationObserver() {
    this.observer = new MutationObserver(mutations => {
      mutations.forEach(mutation => {
        mutation.addedNodes.forEach(node => {
          if (node.nodeType === Node.ELEMENT_NODE) {
            // Check the new element
            if (this.isLikelyAd(node)) {
              this.blockElement(node, 'mutation-observer');
            }
            
            // Check children
            const selectors = this.getBlockingSelectors();
            selectors.forEach(selector => {
              try {
                const matches = node.querySelectorAll ? node.querySelectorAll(selector) : [];
                matches.forEach(el => this.blockElement(el, 'css-selector-dynamic'));
              } catch (e) {}
            });
          }
        });
      });
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }

  overrideAdFunctions() {
    const script = document.createElement('script');
    script.textContent = `
      (function() {
        // Override Google AdSense
        window.adsbygoogle = window.adsbygoogle || [];
        window.adsbygoogle.push = function() { return false; };
        
        // Override common ad functions
        window.showAd = function() { return false; };
        window.displayAd = function() { return false; };
        
        // Block popup functions
        const originalOpen = window.open;
        window.open = function(url, name, features) {
          if (url && (url.includes('popup') || url.includes('ad'))) {
            return null;
          }
          return originalOpen.apply(this, arguments);
        };
        
        // Override eval for ad scripts
        const originalEval = window.eval;
        window.eval = function(code) {
          if (typeof code === 'string' && /ad|sponsor|track/i.test(code)) {
            return null;
          }
          return originalEval.apply(this, arguments);
        };
      })();
    `;
    (document.head || document.documentElement).appendChild(script);
    script.remove();
  }

  setupElementPicker() {
    document.addEventListener('keydown', (e) => {
      // Ctrl+Shift+X to activate element picker
      if (e.ctrlKey && e.shiftKey && e.key === 'X') {
        this.toggleElementPicker();
      }
    });
  }

  toggleElementPicker() {
    this.isPickerActive = !this.isPickerActive;
    
    if (this.isPickerActive) {
      this.startElementPicker();
    } else {
      this.stopElementPicker();
    }
  }

  startElementPicker() {
    document.body.style.cursor = 'crosshair';
    
    // Add overlay styles
    const style = document.createElement('style');
    style.id = 'element-picker-style';
    style.textContent = `
      .element-picker-highlight {
        outline: 2px solid #ff4444 !important;
        outline-offset: 2px !important;
        background: rgba(255, 68, 68, 0.1) !important;
      }
    `;
    document.head.appendChild(style);

    this.elementPicker = {
      mouseover: (e) => {
        e.stopPropagation();
        e.target.classList.add('element-picker-highlight');
      },
      mouseout: (e) => {
        e.stopPropagation();
        e.target.classList.remove('element-picker-highlight');
      },
      click: (e) => {
        e.preventDefault();
        e.stopPropagation();
        this.blockElement(e.target, 'manual-picker');
        this.stopElementPicker();
      }
    };

    document.addEventListener('mouseover', this.elementPicker.mouseover, true);
    document.addEventListener('mouseout', this.elementPicker.mouseout, true);
    document.addEventListener('click', this.elementPicker.click, true);
    
    // Show notification
    this.showPickerNotification('Element picker active. Click to block elements. Press Ctrl+Shift+X to exit.');
  }

  stopElementPicker() {
    document.body.style.cursor = '';
    
    if (this.elementPicker) {
      document.removeEventListener('mouseover', this.elementPicker.mouseover, true);
      document.removeEventListener('mouseout', this.elementPicker.mouseout, true);
      document.removeEventListener('click', this.elementPicker.click, true);
      this.elementPicker = null;
    }

    // Remove highlight class from all elements
    document.querySelectorAll('.element-picker-highlight').forEach(el => {
      el.classList.remove('element-picker-highlight');
    });

    // Remove styles
    const style = document.getElementById('element-picker-style');
    if (style) style.remove();
  }

  showPickerNotification(message) {
    const notification = document.createElement('div');
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      left: 50%;
      transform: translateX(-50%);
      background: #2d3748;
      color: white;
      padding: 12px 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      z-index: 999999;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      font-size: 14px;
    `;
    notification.textContent = message;
    document.body.appendChild(notification);

    setTimeout(() => notification.remove(), 5000);
  }

  reportBlockedElement(url, reason) {
    // This would typically send to background script
    console.log(`Blocked element: ${url} (${reason})`);
  }

  handleMessage(request, sender, sendResponse) {
    switch (request.action) {
      case 'toggleElementPicker':
        this.toggleElementPicker();
        sendResponse({ success: true });
        break;
      case 'updateSettings':
        this.settings = request.settings;
        sendResponse({ success: true });
        break;
    }
  }
}

// Initialize content script
new ContentScriptBlocker();