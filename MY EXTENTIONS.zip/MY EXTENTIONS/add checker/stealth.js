// Stealth Script - Anti-Detection for Ad Blocker
// This script runs in the page context to prevent ad blocker detection

(function() {
  'use strict';

  // Override console methods to hide ad blocker traces
  const originalConsole = {
    log: console.log,
    warn: console.warn,
    error: console.error
  };

  console.log = function(...args) {
    const message = args.join(' ');
    if (!/adblock|ad.block|ublock/i.test(message)) {
      originalConsole.log.apply(console, args);
    }
  };

  console.warn = function(...args) {
    const message = args.join(' ');
    if (!/adblock|ad.block|ublock/i.test(message)) {
      originalConsole.warn.apply(console, args);
    }
  };

  console.error = function(...args) {
    const message = args.join(' ');
    if (!/adblock|ad.block|ublock/i.test(message)) {
      originalConsole.error.apply(console, args);
    }
  };

  // Hide extension from navigator.plugins
  if (navigator.plugins) {
    Object.defineProperty(navigator, 'plugins', {
      get: function() {
        return Object.freeze([]);
      }
    });
  }

  // Override common ad blocker detection methods
  const adBlockDetectors = [
    'detect-adblock',
    'adblock-detect',
    'adBlockDetected',
    'checkAdBlock',
    'adblockDetector'
  ];

  adBlockDetectors.forEach(name => {
    Object.defineProperty(window, name, {
      get: function() { return false; },
      set: function() { return false; }
    });
  });

  // Fake Google AdSense
  window.google_jobrunner = { 
    startInlineReviewFlow: function() {},
    endInlineReviewFlow: function() {}
  };

  window.googletag = window.googletag || {};
  window.googletag.cmd = window.googletag.cmd || [];
  window.googletag.apiReady = true;
  window.googletag.display = function() { return false; };
  window.googletag.defineSlot = function() { 
    return {
      addService: function() { return this; },
      setTargeting: function() { return this; },
      setCollapseEmptyDiv: function() { return this; }
    };
  };
  window.googletag.enableServices = function() {};
  window.googletag.pubads = function() {
    return {
      addEventListener: function() {},
      setTargeting: function() { return this; },
      enableSingleRequest: function() {},
      collapseEmptyDivs: function() {},
      enableLazyLoad: function() {},
      refresh: function() {},
      clear: function() {}
    };
  };

  // Override fetch to fake ad requests
  const originalFetch = window.fetch;
  window.fetch = function(url, options) {
    if (typeof url === 'string') {
      // Block known ad domains
      const adDomains = [
        'googleads', 'doubleclick', 'googlesyndication',
        'amazon-adsystem', 'adsystem', 'outbrain', 'taboola'
      ];
      
      if (adDomains.some(domain => url.includes(domain))) {
        return Promise.resolve(new Response('', {
          status: 200,
          statusText: 'OK'
        }));
      }
    }
    return originalFetch.apply(this, arguments);
  };

  // Override XMLHttpRequest
  const originalXHR = window.XMLHttpRequest;
  window.XMLHttpRequest = function() {
    const xhr = new originalXHR();
    const originalOpen = xhr.open;
    
    xhr.open = function(method, url, async, user, password) {
      if (typeof url === 'string') {
        const adDomains = [
          'googleads', 'doubleclick', 'googlesyndication',
          'amazon-adsystem', 'adsystem', 'outbrain', 'taboola'
        ];
        
        if (adDomains.some(domain => url.includes(domain))) {
          // Fake successful response
          setTimeout(() => {
            xhr.readyState = 4;
            xhr.status = 200;
            xhr.responseText = '';
            if (xhr.onreadystatechange) xhr.onreadystatechange();
            if (xhr.onload) xhr.onload();
          }, 0);
          return;
        }
      }
      return originalOpen.apply(this, arguments);
    };
    
    return xhr;
  };

  // Fake jQuery if ad scripts expect it
  if (!window.jQuery && !window.$) {
    window.jQuery = window.$ = function(selector) {
      return {
        ready: function(callback) { 
          if (document.readyState === 'complete') {
            callback();
          } else {
            document.addEventListener('DOMContentLoaded', callback);
          }
          return this;
        },
        hide: function() { return this; },
        show: function() { return this; },
        remove: function() { return this; },
        append: function() { return this; },
        html: function() { return this; },
        text: function() { return this; },
        attr: function() { return this; },
        css: function() { return this; },
        each: function() { return this; },
        length: 0
      };
    };
  }

  // Override Image constructor to fake ad pixels
  const OriginalImage = window.Image;
  window.Image = function() {
    const img = new OriginalImage();
    const originalSrcSetter = Object.getOwnPropertyDescriptor(Image.prototype, 'src') || 
                             Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    
    if (originalSrcSetter && originalSrcSetter.set) {
      Object.defineProperty(img, 'src', {
        set: function(value) {
          // Check if it's a tracking pixel
          const isTrackingPixel = /track|analytics|pixel|beacon/i.test(value) ||
                                 (img.width === 1 && img.height === 1);
          
          if (isTrackingPixel) {
            // Fake successful load
            setTimeout(() => {
              if (img.onload) img.onload();
            }, 0);
            return;
          }
          
          originalSrcSetter.set.call(this, value);
        },
        get: function() {
          return originalSrcSetter.get.call(this);
        }
      });
    }
    
    return img;
  };

  // Override setTimeout/setInterval for ad scripts
  const originalSetTimeout = window.setTimeout;
  const originalSetInterval = window.setInterval;

  window.setTimeout = function(callback, delay, ...args) {
    if (typeof callback === 'string' && /ad|track|analytic/i.test(callback)) {
      return 0; // Return fake timer ID
    }
    return originalSetTimeout.apply(this, arguments);
  };

  window.setInterval = function(callback, delay, ...args) {
    if (typeof callback === 'string' && /ad|track|analytic/i.test(callback)) {
      return 0; // Return fake timer ID
    }
    return originalSetInterval.apply(this, arguments);
  };

  // Fake common ad variables
  window.adblock = false;
  window.canRunAds = true;
  window.isAdBlockActive = false;
  window.adBlockEnabled = false;

  // Override element creation for ad containers
  const originalCreateElement = document.createElement;
  document.createElement = function(tagName) {
    const element = originalCreateElement.call(this, tagName);
    
    if (tagName.toLowerCase() === 'iframe') {
      const originalSrcSetter = Object.getOwnPropertyDescriptor(HTMLIFrameElement.prototype, 'src');
      
      if (originalSrcSetter && originalSrcSetter.set) {
        Object.defineProperty(element, 'src', {
          set: function(value) {
            const adDomains = [
              'googleads', 'doubleclick', 'googlesyndication',
              'amazon-adsystem', 'adsystem', 'outbrain', 'taboola'
            ];
            
            if (adDomains.some(domain => value.includes(domain))) {
              // Don't set the src, fake load event
              setTimeout(() => {
                if (element.onload) element.onload();
                element.dispatchEvent(new Event('load'));
              }, 0);
              return;
            }
            
            originalSrcSetter.set.call(this, value);
          },
          get: function() {
            return originalSrcSetter.get.call(this);
          }
        });
      }
    }
    
    return element;
  };

  // Hide from ad blocker detection scripts
  Object.defineProperty(window, 'AdBlockDetector', {
    get: function() { return undefined; },
    set: function() { return false; }
  });

  // Fake WebGL for fingerprinting protection
  const originalGetContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function(contextType, ...args) {
    if (contextType === 'webgl' || contextType === 'experimental-webgl') {
      // Return fake WebGL context for fingerprinting protection
      const fakeContext = originalGetContext.call(this, contextType, ...args);
      if (fakeContext) {
        const originalGetParameter = fakeContext.getParameter;
        fakeContext.getParameter = function(parameter) {
          // Return generic values for fingerprinting parameters
          switch (parameter) {
            case 37445: return 'Generic GPU';
            case 37446: return 'Generic Vendor';
            default: return originalGetParameter.call(this, parameter);
          }
        };
      }
      return fakeContext;
    }
    return originalGetContext.apply(this, arguments);
  };

  // Prevent detection through missing elements
  const observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      mutation.addedNodes.forEach(function(node) {
        if (node.nodeType === Node.ELEMENT_NODE) {
          // If an ad container is added, fake its presence
          if (node.id && /ad|sponsor|banner/i.test(node.id)) {
            node.style.visibility = 'hidden';
            node.style.position = 'absolute';
            node.style.left = '-9999px';
          }
        }
      });
    });
  });

  if (document.body) {
    observer.observe(document.body, { childList: true, subtree: true });
  } else {
    document.addEventListener('DOMContentLoaded', function() {
      observer.observe(document.body, { childList: true, subtree: true });
    });
  }

  console.log('Stealth mode activated');

})();